/* ===========================================================
   أسطورة الجواهر — الصوت: مؤثرات مولَّدة + موسيقى (مقام الحجاز) + صدى
   =========================================================== */
(function () {
'use strict';
const JL = window.JL, S = () => JL.S;
const AC = window.AudioContext || window.webkitAudioContext;
let ac = null, master, sfxBus, musBus, revIn, noiseBuf, musicOn = false, nextT = 0, step = 0, timer = 0, last = {};

function impulse(sec, decay) {
  const n = ac.sampleRate * sec | 0, b = ac.createBuffer(2, n, ac.sampleRate);
  for (let ch = 0; ch < 2; ch++) { const d = b.getChannelData(ch); for (let i = 0; i < n; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / n, decay); }
  return b;
}
function init() {
  if (!AC) return false;
  if (!ac) {
    try {
      ac = new AC();
      const comp = ac.createDynamicsCompressor(); comp.threshold.value = -16; comp.knee.value = 18; comp.ratio.value = 5; comp.attack.value = .004; comp.release.value = .18;
      master = ac.createGain(); master.gain.value = .9; master.connect(comp); comp.connect(ac.destination);
      sfxBus = ac.createGain(); musBus = ac.createGain(); sfxBus.connect(master); musBus.connect(master);
      const rv = ac.createConvolver(); rv.buffer = impulse(1.3, 2.6); revIn = ac.createGain(); revIn.gain.value = .26; revIn.connect(rv);
      const rvOut = ac.createGain(); rvOut.gain.value = .8; rv.connect(rvOut); rvOut.connect(master);
      noiseBuf = ac.createBuffer(1, ac.sampleRate * 2, ac.sampleRate); const d = noiseBuf.getChannelData(0); for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
      setVolumes();
    } catch (e) { ac = null; return false; }
  }
  if (ac.state === 'suspended') ac.resume();
  return true;
}
function setVolumes() { if (!ac) return; sfxBus.gain.value = S().sound ? Math.pow(S().sfxVol, 1.6) : 0; musBus.gain.value = S().music ? Math.pow(S().musVol, 1.6) * .38 : 0; }

const nt = n => 523.25 * Math.pow(2, n / 12);
function tone(f, d, type, v, when, slide, bus, wet) {
  if (!ac) return; f = Math.min(f, 12000); const t0 = ac.currentTime + (when || 0), o = ac.createOscillator(), g = ac.createGain();
  o.type = type || 'sine'; o.frequency.setValueAtTime(f, t0); if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(30, f + slide), t0 + d);
  g.gain.setValueAtTime(.0001, t0); g.gain.exponentialRampToValueAtTime(v, t0 + .01); g.gain.exponentialRampToValueAtTime(.0001, t0 + d);
  o.connect(g); g.connect(bus || sfxBus); if (wet && revIn) { const w = ac.createGain(); w.gain.value = wet; g.connect(w); w.connect(revIn); }
  o.start(t0); o.stop(t0 + d + .05);
}
// رنين زجاجي: ثلاث توافقيات غير متجانسة
function bell(f, d, v, when) { tone(f, d, 'sine', v, when, 0, sfxBus, .5); tone(f * 2.76, d * .55, 'sine', v * .32, when, 0, sfxBus, .4); tone(f * 5.4, d * .3, 'sine', v * .14, when); }
function noise(d, v, when, f0, f1, type, q) {
  if (!ac) return; const t0 = ac.currentTime + (when || 0), s = ac.createBufferSource(), fl = ac.createBiquadFilter(), g = ac.createGain();
  s.buffer = noiseBuf; fl.type = type || 'lowpass'; fl.Q.value = q || 1; fl.frequency.setValueAtTime(f0, t0); if (f1) fl.frequency.exponentialRampToValueAtTime(f1, t0 + d);
  g.gain.setValueAtTime(v, t0); g.gain.exponentialRampToValueAtTime(.0001, t0 + d);
  s.connect(fl); fl.connect(g); g.connect(sfxBus); s.start(t0, Math.random()); s.stop(t0 + d + .05);
}
const PENT = [0, 2, 4, 7, 9, 12, 14, 16, 19, 21, 24];
const SFX = {
  click: () => { tone(1250, .06, 'triangle', .16); tone(1900, .05, 'sine', .08, .01); },
  open: () => { noise(.22, .18, 0, 500, 2600, 'bandpass', 2); bell(nt(12), .5, .1, .05); },
  close: () => { noise(.18, .14, 0, 2400, 500, 'bandpass', 2); },
  select: () => { tone(880, .08, 'triangle', .2); tone(1320, .12, 'sine', .1, .03); },
  swap: () => { noise(.14, .13, 0, 700, 2400, 'bandpass', 1.5); tone(420, .1, 'sine', .15, 0, 260); },
  bad: () => { tone(200, .2, 'square', .1, 0, -90); tone(150, .22, 'sawtooth', .07, .05, -60); },
  match: c => { const b = PENT[Math.min(c - 1, 8)]; bell(nt(b), .55, .24); bell(nt(b + 7), .5, .15, .05); if (c > 2) bell(nt(b + 12), .6, .1, .1); },
  clear: n => { bell(nt(PENT[Math.min(n, 9)] + 12), .3, .1); },
  special: () => { [0, 4, 7, 12, 16, 19].forEach((n, i) => bell(nt(n + 12), .5, .12, i * .045)); },
  line: () => { noise(.5, .35, 0, 500, 6000, 'bandpass', 3); tone(1800, .4, 'sawtooth', .07, 0, -1300, sfxBus, .2); tone(900, .35, 'square', .05, .05, -500); },
  bomb: () => { noise(.7, .6, 0, 1400, 70, 'lowpass', .8); tone(120, .6, 'sine', .55, 0, -80); tone(60, .7, 'sine', .4, 0, -25); },
  orb: () => { for (let i = 0; i < 8; i++) { tone(nt(7 + (i % 5) * 4) * (i > 4 ? 2 : 1), .22, 'sawtooth', .06, i * .045, 120, sfxBus, .3); } noise(.6, .25, 0, 300, 8000, 'bandpass', 2); },
  ice: () => { noise(.16, .3, 0, 5000, 1800, 'highpass'); tone(2600, .1, 'sine', .14); tone(3400, .12, 'sine', .1, .03); },
  coin: () => { tone(1318, .08, 'square', .09); tone(1760, .28, 'square', .09, .07, 0, sfxBus, .3); },
  star: i => { bell(nt([4, 9, 14][i] + 12), .9, .22); bell(nt([4, 9, 14][i] + 24), .7, .1, .04); },
  win: () => { [0, 4, 7, 12, 7, 12, 16, 19].forEach((n, i) => { bell(nt(n), .8, .2, i * .11); if (i % 2 === 0) tone(nt(n - 12), .35, 'triangle', .14, i * .11, 0, sfxBus, .3); }); },
  lose: () => { [7, 5, 2, -3].forEach((n, i) => { tone(nt(n - 12), .55, 'triangle', .2, i * .22, 0, sfxBus, .4); tone(nt(n - 24), .55, 'sine', .15, i * .22); }); },
  hammer: () => { noise(.12, .3, 0, 2000, 400, 'lowpass'); tone(160, .18, 'sine', .5, .12, -90); noise(.3, .4, .13, 1800, 150, 'lowpass'); },
  shuffle: () => { for (let i = 0; i < 7; i++) { noise(.14, .1, i * .05, 600 + i * 300, 3000, 'bandpass', 3); tone(nt(i * 2), .1, 'triangle', .08, i * .05); } },
  whoosh: () => noise(.3, .18, 0, 400, 3000, 'bandpass', 1),
  combo: n => { [0, 4, 7, 12].slice(0, Math.min(4, n)).forEach((x, i) => bell(nt(x + 12 + n), .6, .13, i * .06)); },
};
JL.sfx = (n, a) => {
  if (!ac || !S().sound) return;
  const now = performance.now(); if (last[n] && now - last[n] < 38 && n !== 'win') return; last[n] = now;
  try { SFX[n](a); } catch (e) {}
};

/* ---------- الموسيقى ---------- */
const HIJ = [0, 1, 4, 5, 7, 8, 10];
const deg = d => { const o = Math.floor(d / 7); return HIJ[((d % 7) + 7) % 7] + 12 * o; };
const MEL = [0, 2, 4, 2, 5, 4, 2, 1, 0, 2, 4, 6, 7, 6, 4, 2, 0, 1, 2, 4, 5, 4, 2, 0, 1, 2, 4, 2, 1, 0, -1, 0];
const CH = [[0, 2, 4], [1, 3, 5], [0, 2, 4], [-2, 0, 2]];
const BASS = [0, 1, 0, -2];
function tick() {
  if (!ac || !musicOn) return;
  while (nextT < ac.currentTime + .4) {
    const w = nextT - ac.currentTime, s = step % 32, bar = (step / 8 | 0) % 4, k = step % 8;
    const chord = CH[bar];
    tone(nt(deg(chord[[0, 1, 2, 1, 2, 1, 0, 1][k]]) - 12), .5, 'triangle', .35, w, 0, musBus, .5);
    if (k === 0) { chord.forEach(d => tone(nt(deg(d) - 12), 2.3, 'sine', .22, w, 0, musBus, .6)); tone(nt(deg(BASS[bar]) - 36), 1.2, 'sine', .8, w, 0, musBus); }
    if (k === 4) tone(nt(deg(BASS[bar]) - 36), .8, 'sine', .55, w, 0, musBus);
    if (MEL[s] >= 0 && (s % 2 === 0 || s % 8 === 5)) tone(nt(deg(MEL[s] + 7)), .6, 'sine', .3, w, 0, musBus, .6);
    if (k % 2 === 1 && ac) { const t0 = ac.currentTime + w, sr = ac.createBufferSource(), fl = ac.createBiquadFilter(), g = ac.createGain(); sr.buffer = noiseBuf; fl.type = 'highpass'; fl.frequency.value = 7000; g.gain.setValueAtTime(.06, t0); g.gain.exponentialRampToValueAtTime(.0001, t0 + .05); sr.connect(fl); fl.connect(g); g.connect(musBus); sr.start(t0, Math.random()); sr.stop(t0 + .08); }
    nextT += .24; step++;
  }
}
JL.audio = {
  init,
  setVolumes,
  startMusic() { if (!ac || musicOn) return; musicOn = true; nextT = ac.currentTime + .1; timer = setInterval(tick, 100); },
  stopMusic() { musicOn = false; clearInterval(timer); },
  duck(on) { if (!ac) return; musBus.gain.setTargetAtTime(on ? Math.pow(S().musVol, 1.6) * .12 : (S().music ? Math.pow(S().musVol, 1.6) * .38 : 0), ac.currentTime, .15); },
};
document.addEventListener('visibilitychange', () => { if (!ac) return; if (document.hidden) ac.suspend(); else ac.resume(); });
})();
