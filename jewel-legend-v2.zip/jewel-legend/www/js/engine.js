/* ===========================================================
   أسطورة الجواهر — المحرك: منطق + رسم + مؤثرات + إدخال
   - لوحة رسم واحدة بحجم الشاشة، كل شيء مرسوم من صور مخبوزة مسبقاً
   - لا تخصيص ذاكرة في الحلقة الساخنة (جسيمات في مصفوفات ثابتة)
   - حماية من التعليق: مهلات + مراقب + إصلاح تلقائي للوحة
   =========================================================== */
(function () {
'use strict';
const JL = window.JL, $ = JL.$, W = JL.W, H = JL.H, TAU = JL.TAU, rnd = JL.rnd, clamp = JL.clamp, S = () => JL.S;
const sfx = (n, a) => JL.sfx(n, a);
const key = (r, c) => r * W + c, dec = k => [(k / W) | 0, k % W];
const ABORT = { abort: true };
const eOutCubic = t => 1 - Math.pow(1 - t, 3);
const eOutBack = t => { const c = 1.70158; return 1 + (c + 1) * Math.pow(t - 1, 3) + c * Math.pow(t - 1, 2); };

const cv = $('#stage'), ctx = cv.getContext('2d', { alpha: false });
let vw = innerWidth, vh = innerHeight, dpr = 1, T = 0, G = null, gameVisible = false, errCount = 0;
const Lay = { cell: 40, ox: 0, oy: 0, pad: 20, size: 0, spr: null, frame: null, glare: null };
const FONT = '900 {s}px Cairo,Tajawal,"Noto Kufi Arabic","Noto Sans Arabic","Segoe UI",Tahoma,sans-serif';
const font = s => FONT.replace('{s}', Math.round(s));

/* ================= الجسيمات (مصفوفات ثابتة) ================= */
const MAXP = 1100, PA = { n: 0 };
['x', 'y', 'vx', 'vy', 'life', 'max', 'size', 'rot', 'vr', 'grav', 'drag', 'a0', 'grow'].forEach(k => PA[k] = new Float32Array(MAXP));
PA.spr = new Uint8Array(MAXP); PA.add = new Uint8Array(MAXP);
const PARR = ['x', 'y', 'vx', 'vy', 'life', 'max', 'size', 'rot', 'vr', 'grav', 'drag', 'a0', 'grow', 'spr', 'add'].map(k => PA[k]);
function P(x, y, vx, vy, life, size, spr, add, grav, drag, rot, vr, a0, grow) {
  if (PA.n >= MAXP) return; const i = PA.n++;
  PA.x[i] = x; PA.y[i] = y; PA.vx[i] = vx; PA.vy[i] = vy; PA.life[i] = life; PA.max[i] = life; PA.size[i] = size; PA.spr[i] = spr; PA.add[i] = add;
  PA.grav[i] = grav || 0; PA.drag[i] = drag || 0; PA.rot[i] = rot || 0; PA.vr[i] = vr || 0; PA.a0[i] = a0 === undefined ? 1 : a0; PA.grow[i] = grow || 0;
}
function updParticles(dt) {
  for (let i = PA.n - 1; i >= 0; i--) {
    const l = PA.life[i] - dt;
    if (l <= 0) { const j = --PA.n; if (i !== j) for (let k = 0; k < PARR.length; k++) PARR[k][i] = PARR[k][j]; continue; }
    PA.life[i] = l; const d = Math.max(0, 1 - PA.drag[i] * dt);
    PA.vx[i] *= d; PA.vy[i] = PA.vy[i] * d + PA.grav[i] * dt; PA.x[i] += PA.vx[i] * dt; PA.y[i] += PA.vy[i] * dt; PA.rot[i] += PA.vr[i] * dt;
  }
}
function drawParticles() {
  const list = JL.SP.list;
  for (let pass = 0; pass < 2; pass++) {
    ctx.globalCompositeOperation = pass ? 'lighter' : 'source-over';
    for (let i = 0; i < PA.n; i++) {
      if (PA.add[i] !== pass) continue;
      const k = PA.life[i] / PA.max[i], a = PA.a0[i] * Math.min(1, k * 2.5); if (a <= .01) continue;
      const s = PA.size[i] * (1 + PA.grow[i] * (1 - k)), r = PA.rot[i];
      ctx.globalAlpha = a > 1 ? 1 : a;
      if (r) { const c = Math.cos(r) * s * dpr, sn = Math.sin(r) * s * dpr; ctx.setTransform(c, sn, -sn, c, PA.x[i] * dpr, PA.y[i] * dpr); }
      else ctx.setTransform(s * dpr, 0, 0, s * dpr, PA.x[i] * dpr, PA.y[i] * dpr);
      ctx.drawImage(list[PA.spr[i]], -.5, -.5, 1, 1);
    }
  }
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0); ctx.globalAlpha = 1; ctx.globalCompositeOperation = 'source-over';
}
const cnt = n => Math.max(1, Math.round(n * JL.Q.part));
const cxOf = c => Lay.ox + (c + .5) * Lay.cell, cyOf = r => Lay.oy + (r + .5) * Lay.cell;

/* ================= الخلفية المتحركة ================= */
const BG = { theme: -1, base: null, sp: null, mote: null, gems: [], t: 0, shoot: null, rayRot: 0 };
function initMotes() {
  const n = JL.Q.motes; BG.mote = { n, x: new Float32Array(n), y: new Float32Array(n), s: new Float32Array(n), v: new Float32Array(n), p: new Float32Array(n) };
  for (let i = 0; i < n; i++) { BG.mote.x[i] = Math.random(); BG.mote.y[i] = Math.random(); BG.mote.s[i] = .5 + Math.random(); BG.mote.v[i] = .3 + Math.random() * .7; BG.mote.p[i] = Math.random() * 6.28; }
  BG.gems = []; for (let i = 0; i < JL.Q.bgGems; i++) BG.gems.push({ x: Math.random(), y: Math.random(), s: 46 + Math.random() * 110, v: .006 + Math.random() * .016, r: Math.random() * 6.28, rv: (Math.random() - .5) * .4, t: rnd(6), a: .05 + Math.random() * .1, ph: Math.random() * 6.28 });
}
function setTheme(i) {
  BG.theme = i; BG.base = JL.bakeBG(i, vw, vh); BG.sp = JL.bakeBGSprites(i); initMotes();
}
function drawBG(dt) {
  BG.t += dt; const t = BG.t, th = JL.THEMES[BG.theme], Q = JL.Q;
  ctx.globalCompositeOperation = 'source-over'; ctx.globalAlpha = 1;
  ctx.drawImage(BG.base, 0, 0, vw, vh);
  const big = Math.max(vw, vh);
  ctx.globalCompositeOperation = 'lighter';
  for (let i = 0; i < Q.blobs; i++) {
    const ph = t * .06 + i * 2.1, sz = big * (.75 + .12 * i), x = vw * (.5 + .38 * Math.sin(ph * 1.3 + i * 1.9)), y = vh * (.4 + .3 * Math.cos(ph + i * 1.7));
    ctx.globalAlpha = .2; ctx.drawImage(BG.sp.blobs[i % 3], x - sz / 2, y - sz / 2, sz, sz);
  }
  if (Q.rays) { BG.rayRot += dt * .025; ctx.globalAlpha = .13; const s = big * 1.9; ctx.save(); ctx.translate(vw / 2, -vh * .05); ctx.rotate(BG.rayRot); ctx.drawImage(BG.sp.rays, -s / 2, -s / 2, s, s); ctx.restore(); }
  // جواهر عائمة ضبابية
  ctx.globalCompositeOperation = 'source-over';
  for (let i = 0; i < BG.gems.length; i++) {
    const g = BG.gems[i]; g.y -= g.v * dt; g.r += g.rv * dt; if (g.y < -.2) { g.y = 1.2; g.x = Math.random(); }
    const x = (g.x + Math.sin(t * .2 + g.ph) * .03) * vw, y = g.y * vh;
    ctx.globalAlpha = g.a * (.8 + .2 * Math.sin(t + g.ph)); ctx.setTransform(dpr, 0, 0, dpr, x * dpr, y * dpr);
    const c = Math.cos(g.r), s = Math.sin(g.r); ctx.transform(c, s, -s, c, 0, 0); ctx.drawImage(BG.sp.gems[g.t], -g.s / 2, -g.s / 2, g.s, g.s);
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  }
  // جسيمات السمة
  const m = BG.mote, k = th.mote; ctx.globalCompositeOperation = 'lighter'; const spr = BG.sp.mote;
  for (let i = 0; i < m.n; i++) {
    let x = m.x[i], y = m.y[i]; const s = m.s[i], v = m.v[i];
    if (k === 'ember') { y -= v * .08 * dt; x += Math.sin(t * 1.5 + m.p[i]) * .02 * dt; }
    else if (k === 'bubble') { y -= v * .05 * dt; x += Math.sin(t * .9 + m.p[i]) * .015 * dt; }
    else if (k === 'snow') { y += v * .06 * dt; x += Math.sin(t * .7 + m.p[i]) * .02 * dt; }
    else if (k === 'firefly') { x += Math.sin(t * .5 + m.p[i]) * .03 * dt; y += Math.cos(t * .4 + m.p[i] * 1.3) * .03 * dt; }
    else if (k === 'dust') { y -= v * .02 * dt; x += v * .012 * dt; }
    else { x += v * .004 * dt; }
    if (y < -.05) y = 1.05; if (y > 1.05) y = -.05; if (x > 1.05) x = -.05; if (x < -.05) x = 1.05;
    m.x[i] = x; m.y[i] = y;
    let a = .75, sz = 5 + s * 9;
    if (k === 'star') { a = .35 + .65 * Math.abs(Math.sin(t * (.8 + v) + m.p[i])); sz = 7 + s * 12; }
    else if (k === 'firefly') { a = Math.max(0, Math.sin(t * 1.2 + m.p[i])) ; sz = 10 + s * 14; }
    else if (k === 'bubble') { a = .6; sz = 8 + s * 22; }
    else if (k === 'snow') { sz = 5 + s * 9; }
    else if (k === 'ember') { a = .5 + .5 * Math.sin(t * 5 + m.p[i]); sz = 6 + s * 10; }
    ctx.globalAlpha = a; ctx.drawImage(spr, x * vw - sz / 2, y * vh - sz / 2, sz, sz);
  }
  // نجمة عابرة (السمة الملكية)
  if (k === 'star' && Q.level > 0) {
    if (!BG.shoot && Math.random() < dt * .12) BG.shoot = { x: Math.random() * vw * .8 + vw * .2, y: Math.random() * vh * .3, t: 0 };
    if (BG.shoot) { const s = BG.shoot; s.t += dt; const u = s.t / .9; if (u >= 1) BG.shoot = null; else { const x = s.x - u * vw * .4, y = s.y + u * vh * .22; ctx.globalAlpha = Math.sin(u * Math.PI); for (let j = 0; j < 8; j++) ctx.drawImage(spr, x + j * 14 - 9, y - j * 8 - 9, 18 - j, 18 - j); } }
  }
  ctx.globalAlpha = 1; ctx.globalCompositeOperation = 'source-over';
}

/* ================= التخطيط والصور المقاسة ================= */
function resizeStage() {
  vw = innerWidth; vh = innerHeight; dpr = Math.min(window.devicePixelRatio || 1, JL.Q.dpr);
  cv.width = Math.round(vw * dpr); cv.height = Math.round(vh * dpr); cv.style.width = vw + 'px'; cv.style.height = vh + 'px';
  if (BG.theme >= 0) { BG.base = JL.bakeBG(BG.theme, vw, vh); initMotes(); }
  if (gameVisible) layoutBoard();
}
function buildSprites() {
  const cell = Lay.cell, px = Math.round(cell * dpr * 1.12), M = JL.MASTER, sc = JL.scaleTo, ip = Math.round(cell * dpr);
  Lay.spr = {
    gem: M.gem.map(g => sc(g, px)), arrows: sc(M.arrows, px), ring: sc(M.ring, px), orbDisk: sc(M.orbDisk, px), orbGlass: sc(M.orbGlass, px),
    ice1: sc(M.ice1, ip), ice2: sc(M.ice2, ip), hammer: sc(M.hammer, Math.round(cell * dpr * 2.4)),
    mini: M.gem.map(g => sc(g, Math.round(34 * dpr))),
  };
}
function layoutBoard() {
  const slot = $('#boardSlot'), r = slot.getBoundingClientRect();
  if (r.width < 20 || r.height < 20) return false;
  Lay.cell = clamp(Math.floor(Math.min(r.width / W, r.height / H)), 20, 90);
  Lay.ox = Math.round(r.left + (r.width - Lay.cell * W) / 2); Lay.oy = Math.round(r.top + (r.height - Lay.cell * H) / 2);
  buildSprites(); bakeFrame(); if (G) cachChips();
  return true;
}
function bakeFrame() {
  const cell = Lay.cell, pad = Math.round(cell * .55), size = cell * W + pad * 2; Lay.pad = pad; Lay.size = size;
  const hole = G ? G.hole : null, mkc = () => { const c = JL.mk(Math.round(size * dpr)); const x = c.getContext('2d'); x.scale(dpr, dpr); return [c, x]; };
  const [c, x] = mkc(), cells = [];
  for (let r = 0; r < H; r++) for (let q = 0; q < W; q++) if (!hole || !hole[r][q]) cells.push([q * cell + pad, r * cell + pad, r, q]);
  const union = (e, rad) => { x.beginPath(); for (const p of cells) { const a = p[0] - e, b = p[1] - e, w = cell + 2 * e; x.moveTo(a + rad, b); x.arcTo(a + w, b, a + w, b + w, rad); x.arcTo(a + w, b + w, a, b + w, rad); x.arcTo(a, b + w, a, b, rad); x.arcTo(a, b, a + w, b, rad); x.closePath(); } };
  x.save(); x.shadowColor = 'rgba(0,0,0,.65)'; x.shadowBlur = cell * .35; x.shadowOffsetY = cell * .12; x.fillStyle = '#12062e'; union(cell * .2, cell * .3); x.fill(); x.restore();
  let g = x.createLinearGradient(0, 0, size, size); g.addColorStop(0, '#fff2a8'); g.addColorStop(.25, '#ffc928'); g.addColorStop(.55, '#b56a0a'); g.addColorStop(.8, '#ffd86a'); g.addColorStop(1, '#8a4a00');
  x.fillStyle = g; union(cell * .2, cell * .3); x.fill();
  x.fillStyle = '#3f1f04'; union(cell * .155, cell * .26); x.fill();
  g = x.createLinearGradient(size, size, 0, 0); g.addColorStop(0, '#ffe58a'); g.addColorStop(.5, '#c47a12'); g.addColorStop(1, '#fff0a0'); x.fillStyle = g; union(cell * .13, cell * .24); x.fill();
  g = x.createLinearGradient(0, 0, 0, size); g.addColorStop(0, '#201050'); g.addColorStop(1, '#0c0626'); x.fillStyle = g; union(cell * .085, cell * .2); x.fill();
  x.strokeStyle = 'rgba(255,255,255,.07)'; x.lineWidth = 1;
  const ins = cell * .045, rad = cell * .17;
  for (const p of cells) {
    const a = p[0] + ins, b = p[1] + ins, w = cell - ins * 2;
    x.beginPath(); x.moveTo(a + rad, b); x.arcTo(a + w, b, a + w, b + w, rad); x.arcTo(a + w, b + w, a, b + w, rad); x.arcTo(a, b + w, a, b, rad); x.arcTo(a, b, a + w, b, rad); x.closePath();
    x.fillStyle = (p[2] + p[3]) % 2 ? 'rgba(255,255,255,.085)' : 'rgba(255,255,255,.035)'; x.fill();
    g = x.createLinearGradient(0, b, 0, b + w); g.addColorStop(0, 'rgba(255,255,255,.1)'); g.addColorStop(.3, 'rgba(255,255,255,0)'); g.addColorStop(1, 'rgba(0,0,0,.18)'); x.fillStyle = g; x.fill(); x.stroke();
  }
  Lay.frame = c;
  const [gc, gx] = mkc(); gx.save(); gx.beginPath();
  for (const p of cells) { const a = p[0], b = p[1]; gx.rect(a, b, cell, cell); } gx.clip();
  g = gx.createLinearGradient(0, 0, size, size); g.addColorStop(0, 'rgba(255,255,255,.14)'); g.addColorStop(.28, 'rgba(255,255,255,.03)'); g.addColorStop(.3, 'rgba(255,255,255,0)'); g.addColorStop(.56, 'rgba(255,255,255,.05)'); g.addColorStop(.62, 'rgba(255,255,255,0)');
  gx.fillStyle = g; gx.fillRect(0, 0, size, size); gx.restore(); Lay.glare = gc;
}

/* ================= الحالة ================= */
const mkGem = (t, s) => ({ t, s: s || 0, x: 0, y: 0, vy: 0, fall: false, top: -99, dying: false, dt0: 0, dp: 0, pop: 0, sq: 0, sqv: 0, tgt: -1, lift: 0, ph: Math.random() * 6.28 });
const at = (r, c) => (r >= 0 && r < H && c >= 0 && c < W) ? G.board[r][c] : null;
const randType = () => rnd(G.L.colors);
function segTop(r, c) { while (r - 1 >= 0 && !G.hole[r - 1][c]) r--; return r; }

function wait(sec) { const g = G; return new Promise((res, rej) => { if (!g) return rej(ABORT); g.waits.push({ t: sec, res, rej }); }); }
function abortAll(g) { const w = g.waits.splice(0); w.forEach(x => x.rej(ABORT)); }
function later(sec, fn) { if (sec <= 0) { fn(); return; } G.timers.push({ t: sec, fn }); }
async function act(fn) {
  const g = G; if (!g) return; const tok = ++g.run; g.busy = true; g.busyT = 0;
  try { await fn(tok); } catch (e) { if (e !== ABORT) { console.error(e); if (G === g && g.run === tok) { repairBoard(); } } }
  finally { if (G === g && g.run === tok && !g.over) g.busy = false; }
}
function isSettled() {
  for (let r = 0; r < H; r++) for (let c = 0; c < W; c++) { const g = G.board[r][c]; if (g && (g.fall || Math.abs(g.x - c) > .012 || Math.abs(g.y - r) > .012)) return false; }
  return true;
}
function snapAll() { for (let r = 0; r < H; r++) for (let c = 0; c < W; c++) { const g = G.board[r][c]; if (g) { g.x = c; g.y = r; g.vy = 0; g.fall = false; } } }
async function settle() { let t = 0; await wait(0); while (!isSettled()) { await wait(0); t += 1 / 60; if (t > 3.2) { snapAll(); break; } } }
function repairBoard() {
  if (!G) return;
  for (let r = 0; r < H; r++) for (let c = 0; c < W; c++) { const g = G.board[r][c]; if (g && g.dying) G.board[r][c] = null; }
  gravity(); snapAll(); G.sel = null; G.drag = null; G.timers.length = 0;
}
function unstick() {
  const g = G; console.warn('watchdog: recovering'); g.run++; abortAll(g); repairBoard(); g.busy = false; g.busyT = 0; g.fx.length = 0;
  if (!g.over) act(async () => { if (findRuns().length) await cascade(null, null); await afterMove(); });
}

/* ================= البداية ================= */
function fillBoard() {
  let guard = 0;
  do {
    for (let r = 0; r < H; r++) for (let c = 0; c < W; c++) {
      G.board[r][c] = null; if (G.hole[r][c]) continue;
      let t, k = 0;
      do { t = randType(); k++; } while (k < 30 && ((c >= 2 && at(r, c - 1) && at(r, c - 2) && at(r, c - 1).t === t && at(r, c - 2).t === t) || (r >= 2 && at(r - 1, c) && at(r - 2, c) && at(r - 1, c).t === t && at(r - 2, c).t === t)));
      const g = mkGem(t); g.x = c; g.y = r - H - 2 - c * .32 - r * .22; g.fall = true; const tp = segTop(r, c); if (tp > 0) g.top = tp; G.board[r][c] = g;
    }
  } while ((findRuns().length || !findMove()) && guard++ < 200);
}
function startLevel(n) {
  destroyG();
  const L = JL.makeLevel(n), shape = JL.SHAPES[L.shape];
  G = {
    n, L, board: [], hole: [], ice: [], moves: L.moves, score: 0, dispScore: 0, goals: [], iceLeft: 0, iceTotal: 0, busy: true, over: false, paused: false,
    sel: null, hint: null, idle: 0, tool: null, t: 0, shake: 0, flash: 0, waits: [], timers: [], fx: [], flyers: [], texts: [], run: 0, busyT: 0,
    continued: false, intro: 0, drag: null, banner: null, hammerFx: null, chipPos: [], bad: null, combos: 0
  };
  for (let r = 0; r < H; r++) { G.board[r] = []; G.hole[r] = []; G.ice[r] = []; for (let c = 0; c < W; c++) { G.board[r][c] = null; G.hole[r][c] = shape[r][c] === '#'; G.ice[r][c] = 0; } }
  L.ice.forEach(a => { G.ice[a[0]][a[1]] = a[2]; G.iceLeft++; }); G.iceTotal = G.iceLeft;
  L.goals.forEach(g => G.goals.push({ k: g.k, t: g.t, v: g.v, cur: 0, show: 0 }));
  PA.n = 0;
  fillBoard();
  buildHUD(); layoutBoard(); cachChips(); hudMoves(true);
  act(async () => { await wait(.5); await settle(); await wait(.15); G.hint = null; });
  JL.emit('levelstart', n);
}
function destroyG() { if (G) { abortAll(G); G.over = true; } G = null; PA.n = 0; }

/* ================= المطابقة ================= */
const same = (a, b) => a && b && !a.dying && !b.dying && a.t >= 0 && a.t === b.t;
function findRuns() {
  const runs = [];
  for (let r = 0; r < H; r++) { let c = 0; while (c < W) { const g = at(r, c); if (!g) { c++; continue; } let e = c + 1; while (e < W && same(g, at(r, e))) e++; if (e - c >= 3) runs.push({ d: 'h', cells: Array.from({ length: e - c }, (_, i) => key(r, c + i)) }); c = e; } }
  for (let c = 0; c < W; c++) { let r = 0; while (r < H) { const g = at(r, c); if (!g) { r++; continue; } let e = r + 1; while (e < H && same(g, at(e, c))) e++; if (e - r >= 3) runs.push({ d: 'v', cells: Array.from({ length: e - r }, (_, i) => key(r + i, c)) }); r = e; } }
  return runs;
}
function swapCells(r1, c1, r2, c2) { const b = G.board, t = b[r1][c1]; b[r1][c1] = b[r2][c2]; b[r2][c2] = t; }
function findMove() {
  for (let r = 0; r < H; r++) for (let c = 0; c < W; c++) {
    if (!at(r, c)) continue;
    for (const d of [[0, 1], [1, 0]]) {
      const r2 = r + d[0], c2 = c + d[1]; if (!at(r2, c2)) continue;
      const a = at(r, c), b = at(r2, c2);
      if (a.s === 4 || b.s === 4 || (a.s && b.s)) return [[r, c], [r2, c2]];
      swapCells(r, c, r2, c2); const ok = findRuns().length > 0; swapCells(r, c, r2, c2);
      if (ok) return [[r, c], [r2, c2]];
    }
  }
  return null;
}
function effect(g, r, c) {
  const out = [];
  if (g.s === 1) { for (let cc = 0; cc < W; cc++) out.push(key(r, cc)); }
  else if (g.s === 2) { for (let rr = 0; rr < H; rr++) out.push(key(rr, c)); }
  else if (g.s === 3) { for (let dr = -2; dr <= 2; dr++) for (let dc = -2; dc <= 2; dc++) if (Math.abs(dr) + Math.abs(dc) <= 2) out.push(key(r + dr, c + dc)); }
  else if (g.s === 4) {
    let tgt = g.tgt;
    if (tgt < 0) { const present = []; for (let rr = 0; rr < H; rr++) for (let cc = 0; cc < W; cc++) { const q = at(rr, cc); if (q && q.t >= 0 && !q.dying) present.push(q.t); } tgt = present.length ? present[rnd(present.length)] : 0; g.tgt = tgt; }
    for (let rr = 0; rr < H; rr++) for (let cc = 0; cc < W; cc++) { const q = at(rr, cc); if (q && q.t === tgt) out.push(key(rr, cc)); }
  }
  return out.filter(k => { const p = dec(k); return p[0] >= 0 && p[0] < H && p[1] >= 0 && p[1] < W && at(p[0], p[1]); });
}
function gravity() {
  for (let c = 0; c < W; c++) {
    let r = H - 1;
    while (r >= 0) {
      if (G.hole[r][c]) { r--; continue; }
      let top = r; while (top - 1 >= 0 && !G.hole[top - 1][c]) top--;
      let w = r;
      for (let i = r; i >= top; i--) { const g = G.board[i][c]; if (g) { if (i !== w) { G.board[w][c] = g; G.board[i][c] = null; g.fall = true; } w--; } }
      let k = 0;
      for (let i = w; i >= top; i--) { const g = mkGem(randType()); g.x = c; g.y = top - 1.2 - k * 1.05; g.fall = true; g.vy = 3; if (top > 0) g.top = top; G.board[i][c] = g; k++; }
      r = top - 1;
    }
  }
}
function posOf(g) { for (let r = 0; r < H; r++) for (let c = 0; c < W; c++) if (G.board[r][c] === g) return [r, c]; return null; }

/* ---------- مؤثرات الموت والتفعيل ---------- */
function emitDeath(g, r, c) {
  const x = cxOf(c), y = cyOf(r), col = g.t >= 0 ? g.t : 6, cell = Lay.cell, I = JL.SP.I;
  const n = cnt(g.s ? 9 : 5);
  for (let i = 0; i < n; i++) {
    const a = Math.random() * TAU, sp = cell * (2.2 + Math.random() * 5);
    P(x, y, Math.cos(a) * sp, Math.sin(a) * sp - cell * 2.4, .55 + Math.random() * .5, cell * (.2 + Math.random() * .2), I.shard[col * 2 + (i & 1)], 0, cell * 15, .6, Math.random() * 6, (Math.random() - .5) * 16, 1, 0);
  }
  P(x, y, 0, 0, .34, cell * 1.9, I.dot[col], 1, 0, 0, 0, 0, .95, .5);
  P(x, y, 0, 0, .42, cell * 1.25, I.star, 1, 0, 0, Math.random() * 3, 3, .95, .3);
  const n2 = cnt(g.s ? 8 : 4);
  for (let i = 0; i < n2; i++) { const a = Math.random() * TAU, sp = cell * (3 + Math.random() * 6); P(x, y, Math.cos(a) * sp, Math.sin(a) * sp, .3 + Math.random() * .35, cell * (.14 + Math.random() * .12), I.dot[col], 1, 0, 2.2, 0, 0, 1, 0); }
}
function addText(x, y, txt, col, size, life) { if (G.texts.length > 14) G.texts.shift(); G.texts.push({ x, y, txt, col, size, life, max: life }); }
function banner(txt, sub, col) { G.banner = { txt, sub: sub || '', t: 0, dur: 1.6, col: col || 0 }; }
function actFX(a, delay) {
  const cell = Lay.cell, I = JL.SP.I, x = cxOf(a.c), y = cyOf(a.r);
  later(delay, () => {
    if (!G) return;
    if (a.s === 1 || a.s === 2) {
      G.fx.push({ type: 'beam', dir: a.s === 1 ? 'h' : 'v', r: a.r, c: a.c, t: 0, dur: .55 }); sfx('line'); G.shake = Math.max(G.shake, .35); JL.vib(25);
      for (let i = 0; i < cnt(14); i++) { const s = (i / 14 - .5) * (a.s === 1 ? W : H) * cell, sp = (Math.random() - .5) * cell * 3; P(a.s === 1 ? x + s : x + sp, a.s === 1 ? y + sp : y + s, 0, -cell * 1.5, .5, cell * .32, I.dot[7], 1, 0, 1, 0, 0, .9, .3); }
    } else if (a.s === 3) {
      G.fx.push({ type: 'ring', x, y, t: 0, dur: .6, rad: cell * 3.3, col: '255,196,70' }); G.fx.push({ type: 'ring', x, y, t: -.08, dur: .6, rad: cell * 2.4, col: '255,255,255' }); G.fx.push({ type: 'flash', t: 0, dur: .3, a: .4 });
      sfx('bomb'); G.shake = Math.max(G.shake, .8); JL.vib(60);
      for (let i = 0; i < cnt(22); i++) { const an = Math.random() * TAU, sp = cell * (3 + Math.random() * 8); P(x, y, Math.cos(an) * sp, Math.sin(an) * sp, .5 + Math.random() * .4, cell * (.3 + Math.random() * .3), I.dot[i % 2 ? 6 : 7], 1, cell * 3, 2.4, 0, 0, .95, .8); }
    } else if (a.s === 4) {
      sfx('orb'); G.shake = Math.max(G.shake, .4); G.fx.push({ type: 'ring', x, y, t: 0, dur: .5, rad: cell * 2, col: '200,170,255' }); JL.vib(40);
      a.eff.forEach((k, i) => { const p = dec(k); G.fx.push({ type: 'bolt', x, y, tx: cxOf(p[1]), ty: cyOf(p[0]), t: -i * .018, dur: .5, seed: i * 7 }); });
    }
  });
}

/* ---------- التفاعل المتسلسل ---------- */
const COMBO_TXT = ['', '', 'رائع!', 'مذهل!', 'خرافي!', 'أسطوري!'];
async function cascade(forced, pref) {
  let combo = 0, guard = 0;
  while (guard++ < 40) {
    const runs = findRuns(), hasF = forced && forced.size;
    if (!runs.length && !hasF) break;
    combo++;
    const clear = new Set(hasF ? forced : []); forced = null;
    const spawn = new Map(), hm = new Set(), vm = new Set();
    for (const run of runs) for (const k of run.cells) { clear.add(k); (run.d === 'h' ? hm : vm).add(k); }
    for (const run of runs) {
      const L = run.cells.length; if (L < 4) continue;
      let k = run.cells[(L / 2) | 0];
      if (pref) for (const p of pref) if (run.cells.includes(p)) k = p;
      const p = dec(k), g = at(p[0], p[1]); if (!g || g.s) continue;
      const s = L >= 5 ? 4 : (run.d === 'h' ? 2 : 1), pv = spawn.get(k);
      if (!pv || pv.s < s) spawn.set(k, { s, t: s === 4 ? -1 : g.t });
    }
    for (const k of hm) if (vm.has(k) && !spawn.has(k)) { const p = dec(k), g = at(p[0], p[1]); if (g && !g.s) spawn.set(k, { s: 3, t: g.t }); }
    pref = null;
    for (const k of spawn.keys()) clear.delete(k);
    // تفعيل الخاصة بالتسلسل مع تأخير حسب المسافة
    const acts = [], delay = new Map(), seen = new Set(clear), q = []; clear.forEach(k => { q.push([k, 0, 0]); });
    while (q.length) {
      const it = q.pop(), k = it[0], p = dec(k), g = at(p[0], p[1]); if (!g || !g.s) continue;
      const eff = effect(g, p[0], p[1]), base = it[1], a = { r: p[0], c: p[1], s: g.s, eff, delay: base };
      acts.push(a);
      for (const kk of eff) {
        const d = dec(kk), dist = Math.abs(d[0] - p[0]) + Math.abs(d[1] - p[1]), dl = base + (g.s === 4 ? .22 : .035 * dist) + .06;
        if (!seen.has(kk)) { seen.add(kk); clear.add(kk); q.push([kk, dl, 0]); spawn.delete(kk); delay.set(kk, dl); }
      }
    }
    // تدمير
    let pts = 0, sx = 0, sy = 0, n = 0, maxD = 0;
    for (const k of clear) {
      const p = dec(k), r = p[0], c = p[1], g = at(r, c); if (!g || g.dying) continue;
      const dl = delay.get(k) || 0; if (dl > maxD) maxD = dl;
      g.dying = true; g.dt0 = dl; g.dp = 0; g.lift = 0; n++; sx += c; sy += r;
      if (G.ice[r][c] > 0) {
        G.ice[r][c]--; if (G.ice[r][c] === 0) { G.iceLeft--; creditIce(r, c, dl); }
        later(dl, () => { sfx('ice'); iceBurst(r, c); });
      }
      if (g.t >= 0) { const gi = G.goals.findIndex(o => o.k === 'col' && o.t === g.t); if (gi >= 0) { G.goals[gi].cur++; creditGem(gi, r, c, g.t, dl); } }
      pts += 20 * Math.min(combo, 6) + (g.s ? 40 : 0);
    }
    acts.forEach(a => actFX(a, a.delay));
    for (const kv of spawn) {
      const p = dec(kv[0]), g = at(p[0], p[1]), v = kv[1]; if (!g) continue;
      g.t = v.t; g.s = v.s; g.pop = 1; g.tgt = -1;
      G.fx.push({ type: 'ring', x: cxOf(p[1]), y: cyOf(p[0]), t: 0, dur: .45, rad: Lay.cell * 1.8, col: '255,236,140' });
      for (let i = 0; i < cnt(8); i++) { const an = Math.random() * TAU; P(cxOf(p[1]), cyOf(p[0]), Math.cos(an) * Lay.cell * 4, Math.sin(an) * Lay.cell * 4, .5, Lay.cell * .3, JL.SP.I.starGold, 1, 0, 3, 0, 0, 1, 0); }
    }
    if (spawn.size) { sfx('special'); JL.vib(30); }
    if (acts.length) { /* صوت التفعيل داخل actFX */ } else sfx('match', combo);
    if (combo >= 2) { sfx('combo', combo); }
    G.score += pts; G.combos = Math.max(G.combos, combo);
    if (n) addText(cxOf(sx / n), cyOf(sy / n) - Lay.cell * .2, '\u200E+' + pts, 0, .42, 1.0);
    if (combo >= 2) { const idx = Math.min(combo, 5); banner(COMBO_TXT[idx], '', idx); if (combo >= 3) G.fx.push({ type: 'flash', t: 0, dur: .3, a: .12 + combo * .02 }); }
    hudScore();
    await wait(.22 + maxD + (acts.length ? .2 : 0));
    for (const k of clear) { const p = dec(k), g = at(p[0], p[1]); if (g && g.dying) G.board[p[0]][p[1]] = null; }
    gravity(); await settle();
  }
  return combo;
}
function iceBurst(r, c) {
  const x = cxOf(c), y = cyOf(r), cell = Lay.cell, I = JL.SP.I;
  for (let i = 0; i < cnt(9); i++) { const a = Math.random() * TAU, sp = cell * (2 + Math.random() * 5); P(x, y, Math.cos(a) * sp, Math.sin(a) * sp - cell * 2, .6 + Math.random() * .4, cell * (.18 + Math.random() * .18), I.shard[8 * 2 + (i & 1)], 0, cell * 13, .5, Math.random() * 6, (Math.random() - .5) * 14, 1, 0); }
  P(x, y, 0, 0, .35, cell * 1.6, I.dot[8], 1, 0, 0, 0, 0, .9, .5);
}

/* ================= الأهداف والواجهة ================= */
function buildHUD() {
  $('#hudLevel').textContent = G.n;
  const box = $('#goals'); let h = '';
  G.goals.forEach((g, i) => {
    if (g.k === 'score') h += '<div class="chip" id="chip' + i + '"><svg class="ic"><use href="#i-star"/></svg><b></b></div>';
    else if (g.k === 'col') h += '<div class="chip" id="chip' + i + '"><img src="' + JL.gemURL(g.t, 64) + '" alt=""><b></b></div>';
    else h += '<div class="chip" id="chip' + i + '"><svg class="ic"><use href="#i-snow"/></svg><b></b></div>';
  });
  box.innerHTML = h; G.goals.forEach((g, i) => setChip(i)); updateBoosters(); $('#hudScore').textContent = '0';
}
function chipText(i) {
  const g = G.goals[i];
  if (g.k === 'score') return Math.min(Math.floor(G.dispScore), g.v) + '/' + g.v;
  if (g.k === 'col') return Math.min(g.show, g.v) + '/' + g.v;
  return String(Math.max(0, G.iceTotal - g.show));
}
function goalDone(i) {
  const g = G.goals[i];
  return g.k === 'score' ? G.dispScore >= g.v : g.k === 'col' ? g.show >= g.v : G.iceTotal - g.show <= 0;
}
function setChip(i) {
  const el = $('#chip' + i); if (!el) return; const b = el.lastElementChild; const t = chipText(i); if (b.textContent !== t) b.textContent = t;
  const d = goalDone(i); if (d !== el.classList.contains('done')) { el.classList.toggle('done', d); if (d) { sfx('coin'); el.classList.remove('pulse'); void el.offsetWidth; el.classList.add('pulse'); } }
}
function bumpChip(i) { const el = $('#chip' + i); if (!el) return; el.classList.remove('bump'); void el.offsetWidth; el.classList.add('bump'); }
function cachChips() { if (!G) return; G.goals.forEach((g, i) => { const el = $('#chip' + i); if (!el) return; const r = el.getBoundingClientRect(); G.chipPos[i] = { x: r.left + r.width / 2, y: r.top + r.height / 2 }; }); }
function hudScore() { /* الرقم يُحدَّث تدريجياً في update */ }
function hudMoves(init) {
  const el = $('#hudMoves'), v = Math.max(0, G.moves); if (el.textContent !== String(v)) { el.textContent = v; if (!init) { el.classList.remove('bump'); void el.offsetWidth; el.classList.add('bump'); } }
  $('.movesBadge').classList.toggle('low', G.moves <= 5 && G.moves > 0);
}
function updateBoosters() {
  JL.$$('.boost').forEach(b => { const k = b.dataset.b, n = S().inv[k] || 0; const cn = b.querySelector('.cnt'); cn.textContent = n > 0 ? n : '+'; b.classList.toggle('empty', n <= 0); b.classList.toggle('on', k === 'hammer' && !!(G && G.tool === 'hammer')); });
  const h = $('#toolHint'); if (h) h.classList.toggle('hidden', !(G && G.tool === 'hammer'));
}
function creditGem(i, r, c, t, dl) {
  const g = G.goals[i];
  if (!JL.Q.fly || !G.chipPos[i]) { g.show++; setChip(i); return; }
  later(dl, () => { G.flyers.push({ x: cxOf(c), y: cyOf(r), tx: G.chipPos[i].x, ty: G.chipPos[i].y, t: 0, dur: .6 + Math.random() * .12, spr: Lay.spr.mini[t], i, ph: Math.random() * 6 }); });
}
function creditIce(r, c, dl) {
  const i = G.goals.findIndex(o => o.k === 'ice'); if (i < 0) return; const g = G.goals[i];
  if (!JL.Q.fly || !G.chipPos[i]) { g.show++; setChip(i); return; }
  later(dl + .05, () => { G.flyers.push({ x: cxOf(c), y: cyOf(r), tx: G.chipPos[i].x, ty: G.chipPos[i].y, t: 0, dur: .6 + Math.random() * .12, spr: null, i, ph: Math.random() * 6 }); });
}
function syncGoals() { G.goals.forEach((g, i) => { if (g.k === 'col') g.show = g.cur; else if (g.k === 'ice') g.show = G.iceTotal - G.iceLeft; setChip(i); }); G.flyers.length = 0; }
const goalsMet = () => G.goals.every(g => g.k === 'score' ? G.score >= g.v : g.k === 'col' ? g.cur >= g.v : G.iceLeft <= 0);

/* ================= الحركات ================= */
function comboForced(A, B) {
  const pa = posOf(A), pb = posOf(B), set = new Set(); if (!pa || !pb) return set;
  const add = (r, c) => { if (r >= 0 && r < H && c >= 0 && c < W && at(r, c)) set.add(key(r, c)); };
  const sa = A.s, sb = B.s;
  if (sa === 4 || sb === 4) {
    const cb = sa === 4 ? A : B, ot = cb === A ? B : A, pc = cb === A ? pa : pb;
    if (ot.s === 4) { for (let r = 0; r < H; r++) for (let c = 0; c < W; c++) add(r, c); G.fx.push({ type: 'ring', x: cxOf(pc[1]), y: cyOf(pc[0]), t: 0, dur: .8, rad: Lay.cell * 9, col: '255,255,255' }); }
    else {
      cb.tgt = ot.t; add(pc[0], pc[1]);
      if (ot.s && ot.t >= 0) for (let r = 0; r < H; r++) for (let c = 0; c < W; c++) { const g = at(r, c); if (g && g.t === ot.t && !g.s) { g.s = ot.s === 3 ? 3 : 1 + rnd(2); g.pop = 1; } }
    }
  } else if (sa !== 3 && sb !== 3) {
    for (let c = 0; c < W; c++) add(pb[0], c); for (let r = 0; r < H; r++) add(r, pb[1]);
  } else if (sa === 3 && sb === 3) {
    for (let r = 0; r < H; r++) for (let c = 0; c < W; c++) if (Math.abs(r - pb[0]) + Math.abs(c - pb[1]) <= 4) add(r, c);
    G.fx.push({ type: 'ring', x: cxOf(pb[1]), y: cyOf(pb[0]), t: 0, dur: .7, rad: Lay.cell * 5.5, col: '255,160,60' });
  } else {
    for (let d = -1; d <= 1; d++) { for (let c = 0; c < W; c++) add(pb[0] + d, c); for (let r = 0; r < H; r++) add(r, pb[1] + d); }
  }
  add(pa[0], pa[1]); add(pb[0], pb[1]);
  return set;
}
async function trySwap(r1, c1, r2, c2) {
  if (!G || G.busy || G.over || G.paused) return;
  const A = at(r1, c1), B = at(r2, c2); if (!A || !B || A.dying || B.dying) return;
  await act(async () => {
    G.hint = null; G.idle = 0; G.sel = null; G.drag = null; sfx('swap');
    swapCells(r1, c1, r2, c2); A.lift = 1;
    await wait(.17); A.lift = 0;
    const comboSp = A.s === 4 || B.s === 4 || (A.s && B.s), runs = findRuns();
    if (!runs.length && !comboSp) {
      swapCells(r1, c1, r2, c2); sfx('bad'); A.lift = 1; G.bad = { t: 0, a: A, b: B }; await wait(.2); A.lift = 0; return;
    }
    JL.vib(15); G.moves--; hudMoves();
    const forced = comboSp ? comboForced(A, B) : null;
    if (comboSp) { G.fx.push({ type: 'flash', t: 0, dur: .35, a: .3 }); sfx('special'); }
    await cascade(forced, [key(r1, c1), key(r2, c2)]);
    await afterMove();
  });
}
async function afterMove() {
  if (!G || G.over) return;
  if (goalsMet()) { await win(); return; }
  if (G.moves <= 0) { await lose(); return; }
  if (!findMove()) { JL.toast('لا توجد حركات — خلط تلقائي'); await shuffleBoard(); }
}
async function shuffleBoard() {
  const gems = [], cells = [];
  for (let r = 0; r < H; r++) for (let c = 0; c < W; c++) { const g = G.board[r][c]; if (g) { gems.push(g); cells.push([r, c]); } }
  let tries = 0;
  do {
    for (let i = gems.length - 1; i > 0; i--) { const j = rnd(i + 1), t = gems[i]; gems[i] = gems[j]; gems[j] = t; }
    cells.forEach((p, i) => { G.board[p[0]][p[1]] = gems[i]; });
    if (++tries > 60) gems.forEach(g => { if (!g.s) g.t = randType(); });
  } while ((findRuns().length || !findMove()) && tries < 220);
  sfx('shuffle'); G.fx.push({ type: 'flash', t: 0, dur: .4, a: .22 }); gems.forEach(g => { g.pop = .8; });
  const I = JL.SP.I; for (let i = 0; i < cnt(26); i++) { const a = Math.random() * TAU, d = Lay.cell * (1 + Math.random() * 3); P(Lay.ox + W * Lay.cell / 2, Lay.oy + H * Lay.cell / 2, Math.cos(a) * d * 3, Math.sin(a) * d * 3, .7, Lay.cell * .3, I.starGold, 1, 0, 2, 0, 0, 1, 0); }
  await wait(.15); await settle();
}
async function win() {
  G.over = true; G.busy = true; G.hint = null; G.sel = null;
  const ratio = G.moves / G.L.moves, stars = ratio >= .4 ? 3 : ratio >= .15 ? 2 : 1;
  banner('أحسنت!', '', 5); sfx('combo', 5); JL.audio.duck(true);
  const n = Math.min(G.moves, 6);
  for (let i = 0; i < n; i++) {
    G.moves--; hudMoves();
    const list = []; for (let r = 0; r < H; r++) for (let c = 0; c < W; c++) { const g = at(r, c); if (g && !g.s && g.t >= 0) list.push([r, c, g]); }
    if (!list.length) break; const it = list[rnd(list.length)], g = it[2]; g.s = 1 + rnd(3); g.pop = 1;
    G.fx.push({ type: 'ring', x: cxOf(it[1]), y: cyOf(it[0]), t: 0, dur: .45, rad: Lay.cell * 1.8, col: '255,236,140' }); sfx('special');
    await wait(.3); await cascade(new Set([key(it[0], it[1])]), null);
  }
  G.score += G.moves * 60; G.moves = 0; hudMoves(); G.dispScore = G.score; syncGoals();
  confetti();
  const first = !(S().stars[G.n] > 0), coins = first ? 50 + stars * 25 : 15 + (stars > (S().stars[G.n] || 0) ? 20 : 0);
  S().stars[G.n] = Math.max(S().stars[G.n] || 0, stars); S().coins += coins; JL.save();
  sfx('win'); JL.vib([80, 40, 80]);
  await wait(1.1);
  JL.emit('win', { n: G.n, stars, score: G.score, coins, first, last: G.n >= JL.LEVELS });
}
async function lose() {
  G.over = true; G.busy = true; sfx('lose'); JL.vib(200); syncGoals(); await wait(.6);
  JL.emit('lose', { n: G.n, score: G.score, canContinue: !G.continued, goals: G.goals.map(g => ({ k: g.k, t: g.t, cur: g.k === 'ice' ? G.iceTotal - G.iceLeft : g.k === 'score' ? G.score : g.cur, v: g.k === 'ice' ? G.iceTotal : g.v })) });
}
function confetti() {
  const I = JL.SP.I, n = cnt(90);
  for (let i = 0; i < n; i++) { const x = Math.random() * vw, side = i % 2; P(side ? -10 : vw + 10, vh * .55 + Math.random() * vh * .2, (side ? 1 : -1) * (150 + Math.random() * 520), -(380 + Math.random() * 620), 2.4 + Math.random() * 1.4, 14 + Math.random() * 10, I.conf[i % 9], 0, 520, .7, Math.random() * 6, (Math.random() - .5) * 14, 1, 0); }
  for (let i = 0; i < cnt(26); i++) { const a = Math.random() * TAU; P(vw / 2, vh * .4, Math.cos(a) * 340, Math.sin(a) * 340, .9, 40 + Math.random() * 30, I.starGold, 1, 0, 2.5, 0, 0, 1, 0); }
}

/* ================= المعززات ================= */
async function useHammer(p) {
  const g = at(p.r, p.c); if (!g || !G || G.busy || G.over) return;
  G.tool = null; updateBoosters();
  await act(async () => {
    S().inv.hammer--; JL.save(); updateBoosters(); G.hint = null; G.sel = null;
    G.hammerFx = { x: cxOf(p.c), y: cyOf(p.r), t: 0 }; sfx('whoosh');
    await wait(.3); G.hammerFx = null; sfx('hammer'); G.shake = Math.max(G.shake, .6); JL.vib(40);
    G.fx.push({ type: 'ring', x: cxOf(p.c), y: cyOf(p.r), t: 0, dur: .4, rad: Lay.cell * 2, col: '255,255,255' });
    await cascade(new Set([key(p.r, p.c)]), null); await afterMove();
  });
}
function booster(k) {
  if (!G || G.busy || G.over || G.paused) return false;
  if ((S().inv[k] || 0) <= 0) return 'buy';
  if (k === 'hammer') { G.tool = G.tool ? null : 'hammer'; G.sel = null; G.drag = null; updateBoosters(); return true; }
  if (k === 'shuffle') { act(async () => { S().inv.shuffle--; JL.save(); updateBoosters(); G.sel = null; G.hint = null; await shuffleBoard(); if (!G.over) await afterMove(); }); return true; }
  if (k === 'moves') {
    S().inv.moves--; JL.save(); G.moves += 5; hudMoves(); updateBoosters(); sfx('coin'); sfx('special');
    addText(Lay.ox + W * Lay.cell / 2, Lay.oy - Lay.cell * .3, '\u200E+5 حركات', 2, .5, 1.4);
    for (let i = 0; i < cnt(14); i++) { const a = Math.random() * TAU; P(Lay.ox + W * Lay.cell / 2, Lay.oy, Math.cos(a) * 240, Math.sin(a) * 240, .6, 22, JL.SP.I.starGold, 1, 0, 3, 0, 0, 1, 0); }
    return true;
  }
}

/* ================= التحديث ================= */
function update(dt) {
  T += dt;
  if (!G) { updParticles(dt); return; }
  if (G.paused) return;
  G.t += dt; G.intro = Math.min(1, G.intro + dt * 2.4);
  // الانتظارات والمؤقتات
  for (let i = G.waits.length - 1; i >= 0; i--) { const w = G.waits[i]; w.t -= dt; if (w.t <= 0) { G.waits.splice(i, 1); w.res(); } }
  for (let i = G.timers.length - 1; i >= 0; i--) { const w = G.timers[i]; w.t -= dt; if (w.t <= 0) { G.timers.splice(i, 1); try { w.fn(); } catch (e) { console.error(e); } } }
  // الجواهر
  const kx = 1 - Math.exp(-dt * 21);
  for (let r = 0; r < H; r++) for (let c = 0; c < W; c++) {
    const g = G.board[r][c]; if (!g) continue;
    const dx = c - g.x; if (Math.abs(dx) < .004) g.x = c; else g.x += dx * kx;
    if (g.fall) {
      g.vy = Math.min(g.vy + 62 * dt, 36); g.y += g.vy * dt;
      if (g.y >= r) { g.y = r; if (g.vy > 6) { g.sq = Math.min(.3, g.vy * .011); g.sqv = 0; g.vy = -g.vy * .17; } else { g.vy = 0; g.fall = false; } }
    } else { const dy = r - g.y; if (Math.abs(dy) < .004) g.y = r; else g.y += dy * kx; }
    if (g.sq !== 0 || g.sqv !== 0) { g.sqv += (-170 * g.sq - 15 * g.sqv) * dt; g.sq += g.sqv * dt; if (Math.abs(g.sq) < .003 && Math.abs(g.sqv) < .05) { g.sq = 0; g.sqv = 0; } }
    if (g.pop > 0) g.pop = Math.max(0, g.pop - dt * 2.8);
    if (g.dying) { if (g.dt0 > 0) { g.dt0 -= dt; if (g.dt0 <= 0) { g.dt0 = 0; emitDeath(g, r, c); } } else g.dp += dt * 4.6; }
  }
  updParticles(dt);
  // نصوص عائمة
  for (let i = G.texts.length - 1; i >= 0; i--) { const t = G.texts[i]; t.life -= dt; t.y -= Lay.cell * .9 * dt; if (t.life <= 0) G.texts.splice(i, 1); }
  // مؤثرات
  for (let i = G.fx.length - 1; i >= 0; i--) { const f = G.fx[i]; f.t += dt; if (f.t >= f.dur) G.fx.splice(i, 1); }
  // طائرات نحو الأهداف
  for (let i = G.flyers.length - 1; i >= 0; i--) {
    const f = G.flyers[i]; f.t += dt;
    if (f.t >= f.dur) { G.flyers.splice(i, 1); const g = G.goals[f.i]; g.show++; setChip(f.i); bumpChip(f.i); const I = JL.SP.I; P(f.tx, f.ty, 0, 0, .3, 56, I.dot[7], 1, 0, 0, 0, 0, .8, .5); sfx('clear', Math.min(g.show, 9)); }
  }
  if (G.shake > 0) G.shake = Math.max(0, G.shake - dt * 2.4);
  if (G.banner) { G.banner.t += dt; if (G.banner.t >= G.banner.dur) G.banner = null; }
  if (G.bad) { G.bad.t += dt; if (G.bad.t > .3) G.bad = null; }
  if (G.hammerFx) G.hammerFx.t += dt;
  // نقاط تصاعدية
  if (G.dispScore < G.score) {
    const step = Math.max(1, (G.score - G.dispScore) * Math.min(1, dt * 7)); const prev = Math.floor(G.dispScore); G.dispScore = Math.min(G.score, G.dispScore + step);
    if (Math.floor(G.dispScore) !== prev) { $('#hudScore').textContent = Math.floor(G.dispScore); G.goals.forEach((g, i) => { if (g.k === 'score') setChip(i); }); }
  }
  // تلميح عند الخمول
  if (!G.busy && !G.over && !G.tool) { G.idle += dt; if (G.idle > 5 && !G.hint) { const m = findMove(); if (m) G.hint = m; else G.idle = 0; } }
  // حارس التعليق
  if (G.busy && !G.over) { G.busyT += dt; if (G.busyT > 20) unstick(); } else G.busyT = 0;
  // سحب الجوهرة
  if (G.drag && (G.busy || G.over)) G.drag = null;
}

/* ================= الرسم ================= */
function isHint(r, c) { const h = G.hint; return h && ((h[0][0] === r && h[0][1] === c) || (h[1][0] === r && h[1][1] === c)); }
function drawGlow(x, y, size, spr, a) { ctx.globalAlpha = a; ctx.drawImage(spr, x - size / 2, y - size / 2, size, size); }
function drawGem(g, r, c) {
  const cell = Lay.cell, spr = Lay.spr, sz = cell * 1.12, M = JL.MASTER;
  let px = Lay.ox + (g.x + .5) * cell, py = Lay.oy + (g.y + .5) * cell, sx = 1, sy = 1, al = 1, rot = 0, flash = 0;
  if (g.dying) {
    if (g.dt0 > 0) flash = .35 + .35 * Math.sin(T * 38);
    else { const u = g.dp; if (u >= 1) return; const s = u < .18 ? 1 + u * 1.6 : Math.max(0, 1.29 * (1 - (u - .18) / .82)); sx = sy = s; al = 1 - u * .7; flash = 1 - u; }
  }
  if (g.top > -50) al *= clamp((g.y - g.top + .9) / .9, 0, 1);
  if (al <= .01) return;
  if (g.sq) { sx *= 1 + g.sq * .6; sy *= 1 - g.sq * .9; }
  if (g.pop > 0) { const p = Math.sin(g.pop * Math.PI) * .42; sx *= 1 + p; sy *= 1 + p; }
  if (g.s) { const b = Math.sin(T * 4 + g.ph) * .035; sx *= 1 + b; sy *= 1 + b; }
  const sel = G.sel && G.sel.r === r && G.sel.c === c, hint = isHint(r, c);
  if (sel) { const b = 1.1 + Math.sin(T * 9) * .03; sx *= b; sy *= b; if (G.drag) { px += G.drag.ox || 0; py += G.drag.oy || 0; } }
  if (hint) { rot = Math.sin(T * 11) * .09; const b = 1 + Math.sin(T * 8) * .07; sx *= b; sy *= b; }
  if (g.lift) { sx *= 1.12; sy *= 1.12; }
  if (G.bad && (G.bad.a === g || G.bad.b === g)) { px += Math.sin(G.bad.t * 70) * cell * .06 * (1 - G.bad.t / .3); }
  const w = sz * sx, h = sz * sy; py += (sz - h) * .5;
  // هالة
  if (JL.Q.glow && (g.s || sel || hint) && !g.dying) {
    ctx.globalCompositeOperation = 'lighter';
    const pulse = .5 + .25 * Math.sin(T * 5 + g.ph);
    if (g.s === 4) { drawGlow(px, py, sz * 1.7, M.glowGold, pulse * .9); drawGlow(px, py, sz * 1.3, M.glow[(Math.floor(T * 2) + r) % 6], pulse * .6); }
    else if (g.s === 3) drawGlow(px, py, sz * 1.6, M.glowGold, pulse);
    else if (g.s) drawGlow(px, py, sz * 1.5, M.glow[g.t], pulse);
    else drawGlow(px, py, sz * 1.5, g.t >= 0 ? M.glow[g.t] : M.glowWhite, hint ? .55 : .6);
    ctx.globalCompositeOperation = 'source-over';
  }
  ctx.globalAlpha = al;
  if (g.s === 4) {
    ctx.save(); ctx.translate(px, py); ctx.rotate(T * 1.3); ctx.drawImage(spr.orbDisk, -w / 2, -h / 2, w, h); ctx.restore();
    ctx.drawImage(spr.orbGlass, px - w / 2, py - h / 2, w, h);
    ctx.globalCompositeOperation = 'lighter'; const sp = JL.SP.list[JL.SP.I.star];
    for (let i = 0; i < 3; i++) { const a = T * 2.2 + i * 2.1; ctx.globalAlpha = al * .9; ctx.drawImage(sp, px + Math.cos(a) * w * .36 - w * .1, py + Math.sin(a) * h * .36 - h * .1, w * .2, h * .2); }
    ctx.globalCompositeOperation = 'source-over';
  } else {
    const gs = spr.gem[g.t];
    if (rot) { ctx.save(); ctx.translate(px, py); ctx.rotate(rot); ctx.drawImage(gs, -w / 2, -h / 2, w, h); ctx.restore(); } else ctx.drawImage(gs, px - w / 2, py - h / 2, w, h);
    if (g.s === 1 || g.s === 2) {
      ctx.globalAlpha = al * (.85 + .15 * Math.sin(T * 6 + g.ph));
      if (g.s === 2) { ctx.save(); ctx.translate(px, py); ctx.rotate(Math.PI / 2); ctx.drawImage(spr.arrows, -w / 2, -h / 2, w, h); ctx.restore(); } else ctx.drawImage(spr.arrows, px - w / 2, py - h / 2, w, h);
    } else if (g.s === 3) {
      ctx.save(); ctx.translate(px, py); ctx.rotate(T * .9); ctx.globalAlpha = al; ctx.drawImage(spr.ring, -w / 2, -h / 2, w, h); ctx.restore();
    }
  }
  if (flash > .02) { ctx.globalCompositeOperation = 'lighter'; ctx.globalAlpha = Math.min(.9, flash); if (g.s === 4) ctx.drawImage(spr.orbGlass, px - w / 2, py - h / 2, w, h); else ctx.drawImage(spr.gem[g.t], px - w / 2, py - h / 2, w, h); ctx.globalCompositeOperation = 'source-over'; }
  ctx.globalAlpha = 1;
}
function drawBoard() {
  const cell = Lay.cell, ox = Lay.ox, oy = Lay.oy, it = G.intro;
  if (!Lay.frame) return;
  ctx.save();
  if (G.shake > 0 && S().shake) { const a = G.shake * cell * .2; ctx.translate((Math.random() - .5) * a, (Math.random() - .5) * a); }
  const sc = .94 + .06 * eOutBack(Math.min(1, it)); if (it < 1) { const cx = ox + W * cell / 2, cy = oy + H * cell / 2; ctx.translate(cx, cy); ctx.scale(sc, sc); ctx.translate(-cx, -cy); }
  ctx.globalAlpha = Math.min(1, it * 1.6); ctx.drawImage(Lay.frame, ox - Lay.pad, oy - Lay.pad, Lay.size, Lay.size); ctx.globalAlpha = 1;
  ctx.save(); ctx.beginPath(); ctx.rect(ox, oy, W * cell, H * cell); ctx.clip();
  let lifted = null;
  for (let r = 0; r < H; r++) for (let c = 0; c < W; c++) { const g = G.board[r][c]; if (!g) continue; if (g.lift) { (lifted = lifted || []).push(g, r, c); continue; } drawGem(g, r, c); }
  if (lifted) for (let i = 0; i < lifted.length; i += 3) drawGem(lifted[i], lifted[i + 1], lifted[i + 2]);
  // الجليد فوق الجواهر
  const ia = .93 + .07 * Math.sin(T * 2);
  for (let r = 0; r < H; r++) for (let c = 0; c < W; c++) { const v = G.ice[r][c]; if (!v) continue; ctx.globalAlpha = ia; ctx.drawImage(v > 1 ? Lay.spr.ice2 : Lay.spr.ice1, ox + c * cell, oy + r * cell, cell, cell); }
  ctx.globalAlpha = 1; ctx.restore();
  ctx.globalAlpha = .9; ctx.drawImage(Lay.glare, ox - Lay.pad, oy - Lay.pad, Lay.size, Lay.size); ctx.globalAlpha = 1;
  // وضع المطرقة: إطار متوهج
  if (G.tool === 'hammer') { ctx.globalCompositeOperation = 'lighter'; ctx.strokeStyle = 'rgba(255,190,60,' + (.4 + .3 * Math.sin(T * 7)) + ')'; ctx.lineWidth = cell * .12; ctx.strokeRect(ox - cell * .06, oy - cell * .06, W * cell + cell * .12, H * cell + cell * .12); ctx.globalCompositeOperation = 'source-over'; }
  drawFX();
  ctx.restore();
}
function drawFX() {
  const cell = Lay.cell, ox = Lay.ox, oy = Lay.oy;
  ctx.globalCompositeOperation = 'lighter';
  for (let i = 0; i < G.fx.length; i++) {
    const f = G.fx[i]; if (f.t < 0) continue; const k = f.t / f.dur;
    if (f.type === 'beam') {
      const x = cxOf(f.c), y = cyOf(f.r), len = (f.dir === 'h' ? W : H) * cell, p = eOutCubic(Math.min(1, k * 2.4)), th = cell * (1.05 - .7 * k), a = 1 - k * k;
      ctx.save(); ctx.translate(x, y); if (f.dir === 'v') ctx.rotate(Math.PI / 2);
      const L = len * p * .5 + cell * .5; let g = ctx.createLinearGradient(0, -th / 2, 0, th / 2); g.addColorStop(0, 'rgba(255,200,80,0)'); g.addColorStop(.35, 'rgba(255,230,150,' + a * .8 + ')'); g.addColorStop(.5, 'rgba(255,255,255,' + a + ')'); g.addColorStop(.65, 'rgba(255,230,150,' + a * .8 + ')'); g.addColorStop(1, 'rgba(255,200,80,0)');
      ctx.fillStyle = g; ctx.fillRect(-L, -th / 2, L * 2, th);
      g = ctx.createRadialGradient(0, 0, 0, 0, 0, cell * 1.2); g.addColorStop(0, 'rgba(255,255,255,' + a + ')'); g.addColorStop(1, 'rgba(255,200,80,0)'); ctx.fillStyle = g; ctx.fillRect(-cell * 1.2, -cell * 1.2, cell * 2.4, cell * 2.4);
      ctx.restore();
    } else if (f.type === 'ring') {
      const rad = f.rad * eOutCubic(k); ctx.strokeStyle = 'rgba(' + f.col + ',' + (1 - k) + ')'; ctx.lineWidth = Math.max(1, cell * .32 * (1 - k)); ctx.beginPath(); ctx.arc(f.x, f.y, rad, 0, TAU); ctx.stroke();
    } else if (f.type === 'flash') {
      ctx.fillStyle = 'rgba(255,250,235,' + f.a * (1 - k) + ')'; ctx.fillRect(ox - cell * .2, oy - cell * .2, W * cell + cell * .4, H * cell + cell * .4);
    } else if (f.type === 'bolt') {
      const a = 1 - k, dx = f.tx - f.x, dy = f.ty - f.y, len = Math.hypot(dx, dy) || 1, nx = -dy / len, ny = dx / len, seg = 7, q = Math.floor(T * 22) + f.seed;
      ctx.beginPath(); ctx.moveTo(f.x, f.y);
      for (let s = 1; s < seg; s++) { const u = s / seg, j = (Math.sin(q * 12.9898 + s * 78.233) * 43758.5453 % 1) * cell * .45 * Math.sin(u * Math.PI); ctx.lineTo(f.x + dx * u + nx * j, f.y + dy * u + ny * j); }
      ctx.lineTo(f.tx, f.ty);
      ctx.strokeStyle = 'rgba(190,150,255,' + a * .7 + ')'; ctx.lineWidth = cell * .22; ctx.lineJoin = 'round'; ctx.stroke(); ctx.strokeStyle = 'rgba(255,255,255,' + a + ')'; ctx.lineWidth = cell * .07; ctx.stroke();
      const sp = JL.SP.list[JL.SP.I.dot[7]]; ctx.globalAlpha = a; ctx.drawImage(sp, f.tx - cell * .6, f.ty - cell * .6, cell * 1.2, cell * 1.2); ctx.globalAlpha = 1;
    }
  }
  ctx.globalCompositeOperation = 'source-over';
  // المطرقة
  if (G.hammerFx) {
    const h = G.hammerFx, u = Math.min(1, h.t / .3), ang = -1.15 + eOutCubic(u * u) * 1.5, s = Lay.spr.hammer, sz = cell * 2.4;
    ctx.save(); ctx.translate(h.x + cell * .55, h.y - cell * .35); ctx.rotate(ang); ctx.drawImage(s, -sz / 2, -sz * .82, sz, sz); ctx.restore();
  }
}
function drawOverlay() {
  if (!G) return;
  const cell = Lay.cell;
  // طائرات الأهداف
  for (let i = 0; i < G.flyers.length; i++) {
    const f = G.flyers[i], u = f.t / f.dur, e = u * u * (3 - 2 * u), mx = (f.x + f.tx) / 2 + Math.sin(f.ph) * 70, my = Math.min(f.y, f.ty) - 60;
    const x = (1 - e) * (1 - e) * f.x + 2 * (1 - e) * e * mx + e * e * f.tx, y = (1 - e) * (1 - e) * f.y + 2 * (1 - e) * e * my + e * e * f.ty;
    const s = 34 * (1 - .35 * e);
    if (f.spr) ctx.drawImage(f.spr, x - s / 2, y - s / 2, s, s);
    else { ctx.globalCompositeOperation = 'lighter'; ctx.drawImage(JL.SP.list[JL.SP.I.dot[8]], x - s / 2, y - s / 2, s, s); ctx.globalCompositeOperation = 'source-over'; }
    if ((i + Math.floor(T * 40)) % 2 === 0) P(x, y, (Math.random() - .5) * 40, (Math.random() - .5) * 40, .3, 14, JL.SP.I.dot[f.spr ? 7 : 8], 1, 0, 0, 0, 0, .8, 0);
  }
  drawParticles();
  // نصوص عائمة
  for (let i = 0; i < G.texts.length; i++) {
    const t = G.texts[i], k = t.life / t.max, a = Math.min(1, k * 2.2), s = cell * t.size * (1 + .25 * Math.max(0, (k - .85) / .15));
    ctx.globalAlpha = a; ctx.font = font(s); ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.lineJoin = 'round'; ctx.lineWidth = s * .22; ctx.strokeStyle = '#3a1c00'; ctx.strokeText(t.txt, t.x, t.y);
    ctx.fillStyle = t.col === 2 ? '#8dffb8' : '#fff3a0'; ctx.fillText(t.txt, t.x, t.y);
  }
  ctx.globalAlpha = 1;
  // لافتة التسلسل
  if (G.banner) {
    const b = G.banner, u = b.t / b.dur, sc = u < .18 ? eOutBack(u / .18) : 1, a = u > .75 ? 1 - (u - .75) / .25 : 1, s = cell * (b.col >= 4 ? 1.35 : 1.05) * sc, x = Lay.ox + W * cell / 2, y = Lay.oy + H * cell * .42 - u * cell * .6;
    ctx.save(); ctx.globalAlpha = a; ctx.font = font(s); ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.lineJoin = 'round';
    ctx.lineWidth = s * .26; ctx.strokeStyle = '#4a0f4f'; ctx.strokeText(b.txt, x, y);
    ctx.lineWidth = s * .1; ctx.strokeStyle = '#fff6c8'; ctx.strokeText(b.txt, x, y + 0);
    const g = ctx.createLinearGradient(0, y - s * .5, 0, y + s * .5); g.addColorStop(0, '#fff7b0'); g.addColorStop(.5, '#ffc928'); g.addColorStop(1, '#ff7a00'); ctx.fillStyle = g; ctx.fillText(b.txt, x, y); ctx.restore();
  }
}
function render() {
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  drawBG(1 / 60 * 0 + (render.dt || 0));
  if (G && gameVisible) { drawBoard(); drawOverlay(); }
  else if (PA.n) { drawParticles(); }
}
let last = performance.now();
function loop(now) {
  requestAnimationFrame(loop);
  const raw = (now - last) / 1000; last = now; const dt = Math.min(.05, raw);
  JL.perf(raw);
  try { render.dt = dt; update(dt); render(); errCount = Math.max(0, errCount - .01); }
  catch (e) { console.error(e); if (++errCount > 8 && G) { errCount = 0; try { unstick(); } catch (e2) {} } }
}

/* ================= الإدخال ================= */
function cellAt(e) {
  const x = (e.clientX - Lay.ox) / Lay.cell, y = (e.clientY - Lay.oy) / Lay.cell, c = Math.floor(x), r = Math.floor(y);
  return (r >= 0 && r < H && c >= 0 && c < W && at(r, c)) ? { r, c } : null;
}
function wireInput() {
  const slot = $('#boardSlot');
  slot.addEventListener('pointerdown', e => {
    JL.audio.init(); if (!G || G.busy || G.over || G.paused || !gameVisible) return; const p = cellAt(e); if (!p) { return; }
    if (G.tool === 'hammer') { useHammer(p); return; }
    G.idle = 0; G.hint = null;
    if (G.sel && G.sel.r === p.r && G.sel.c === p.c) { G.sel = null; G.drag = null; return; }
    if (G.sel && Math.abs(G.sel.r - p.r) + Math.abs(G.sel.c - p.c) === 1) { const s = G.sel; G.sel = null; G.drag = null; trySwap(s.r, s.c, p.r, p.c); return; }
    G.sel = { r: p.r, c: p.c }; G.drag = { r: p.r, c: p.c, x: e.clientX, y: e.clientY, ox: 0, oy: 0 }; sfx('select');
    try { slot.setPointerCapture(e.pointerId); } catch (er) {}
  });
  slot.addEventListener('pointermove', e => {
    if (!G || !G.drag || G.busy || G.over) return;
    const d = G.drag, dx = e.clientX - d.x, dy = e.clientY - d.y, cell = Lay.cell, m = Math.hypot(dx, dy);
    const horiz = Math.abs(dx) > Math.abs(dy), mx = horiz ? clamp(dx, -cell * .5, cell * .5) : 0, my = horiz ? 0 : clamp(dy, -cell * .5, cell * .5);
    d.ox = mx; d.oy = my;
    if (m > cell * .42) {
      const r = d.r, c = d.c; let r2 = r, c2 = c; if (horiz) c2 += dx > 0 ? 1 : -1; else r2 += dy > 0 ? 1 : -1;
      G.drag = null; G.sel = null; if (at(r2, c2)) trySwap(r, c, r2, c2);
    }
  });
  const up = () => { if (G && G.drag) { G.drag.ox = 0; G.drag.oy = 0; G.drag = null; } };
  slot.addEventListener('pointerup', up); slot.addEventListener('pointercancel', up);
}

/* ================= واجهة المحرك العامة ================= */
let rsT = 0;
window.addEventListener('resize', () => { clearTimeout(rsT); rsT = setTimeout(() => { resizeStage(); }, 120); });
if (window.ResizeObserver) { try { new ResizeObserver(() => { if (gameVisible) { clearTimeout(rsT); rsT = setTimeout(() => { layoutBoard(); cachChips(); }, 60); } }).observe($('#boardSlot')); } catch (e) {} }
JL.on('quality', () => { resizeStage(); });
JL.game = {
  init() { dpr = Math.min(window.devicePixelRatio || 1, JL.Q.dpr); resizeStage(); setTheme(S().theme); wireInput(); requestAnimationFrame(loop); },
  setTheme,
  start(n) { startLevel(n); },
  stop() { destroyG(); },
  setVisible(v) { gameVisible = v; if (v) { layoutBoard(); } },
  relayout() { if (layoutBoard()) { cachChips(); } },
  pause(on) { if (G) G.paused = on; },
  booster,
  updateBoosters,
  continueGame() { if (!G) return; G.moves += 5; G.over = false; G.busy = false; G.continued = true; hudMoves(); G.fx.push({ type: 'flash', t: 0, dur: .4, a: .2 }); JL.audio.duck(false); },
  get state() { return G; },
  get level() { return G ? G.n : 0; },
  restart() { if (G) startLevel(G.n); },
};
JL.debug = { get G() { return G; }, trySwap, useHammer, findMove, findRuns, at, snapAll, repairBoard, Lay, PA, shuffleBoard };
})();
