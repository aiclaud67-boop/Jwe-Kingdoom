/* ===========================================================
   أسطورة الجواهر — الواجهات: شاشات، نوافذ، خريطة، متجر، إعدادات، مكافأة يومية
   =========================================================== */
(function () {
'use strict';
const JL = window.JL, $ = JL.$, $$ = JL.$$, S = () => JL.S, sfx = (n, a) => JL.sfx(n, a), icon = JL.icon;
let cur = 'splash', modalOpen = false, modalClosable = true, modalOnClose = null, shownCoins = null;

/* ---------- عناصر مساعدة ---------- */
JL.toast = t => { const el = $('#toast'); el.textContent = t; el.classList.remove('hidden'); el.style.animation = 'none'; void el.offsetWidth; el.style.animation = ''; clearTimeout(JL.toast.h); JL.toast.h = setTimeout(() => el.classList.add('hidden'), 2000); };
function coinsRefresh() {
  const v = S().coins, els = $$('.coinVal'); if (shownCoins === null || shownCoins === v) { els.forEach(e => e.textContent = v); shownCoins = v; return; }
  const from = shownCoins, t0 = performance.now(); shownCoins = v;
  (function step(now) { const u = Math.min(1, (now - t0) / 600), x = Math.round(from + (v - from) * u); els.forEach(e => e.textContent = x); if (u < 1) requestAnimationFrame(step); })(t0);
}
JL.coinsRefresh = coinsRefresh;
const click = () => sfx('click');
const goalChip = g => g.k === 'score' ? '<div class="chip">' + icon('star') + '<b>' + g.v + '</b></div>' : g.k === 'col' ? '<div class="chip"><img src="' + JL.gemURL(g.t, 64) + '" alt=""><b>' + g.v + '</b></div>' : '<div class="chip">' + icon('snow') + '<b>حطّم الجليد</b></div>';

/* ---------- التنقل ---------- */
function show(id) {
  cur = id; $$('.screen').forEach(s => s.classList.toggle('active', s.id === id));
  JL.game.setVisible(id === 'game');
  if (id === 'menu') refreshMenu(); if (id === 'levels') buildMap(); if (id === 'shop') buildShop(); if (id === 'settings') buildSettings();
  coinsRefresh();
}
let armed = false;
function arm() { if (!armed) { try { history.pushState({ a: 1 }, '', '#app'); armed = true; } catch (e) {} } }
function go(id) { if (id !== 'menu') arm(); show(id); }
function home(id) { if (JL.game.state) JL.game.stop(); JL.audio.duck(false); show(id || 'menu'); }
let exitT = 0;
window.addEventListener('popstate', () => {
  armed = false;
  if (modalOpen) { if (modalClosable) closeModal(); arm(); return; }
  if (cur === 'game') { pauseMenu(); arm(); return; }
  if (cur === 'splash') { arm(); return; }
  if (cur !== 'menu') { home('menu'); arm(); return; }
  const now = Date.now(); if (now - exitT > 2000) { exitT = now; JL.toast('اضغط رجوع مرة أخرى للخروج'); arm(); }
});

/* ---------- النوافذ ---------- */
function modal(o) {
  const box = $('#modalBox'); modalClosable = o.closable !== false; modalOnClose = o.onClose || null;
  box.innerHTML = '<h3 class="' + (o.gold ? 'gold' : '') + '">' + o.title + '</h3>' + (o.body || '');
  (o.buttons || []).forEach(b => {
    const el = document.createElement('button'); el.className = 'btn ' + (b.cls || ''); el.innerHTML = (b.icon ? icon(b.icon) : '') + '<span>' + b.t + '</span>'; if (b.dis) el.disabled = true;
    el.onclick = () => { sfx('click'); b.fn && b.fn(); }; box.appendChild(el);
  });
  if (!modalOpen) sfx('open'); modalOpen = true; $('#modal').classList.remove('hidden');
  box.style.animation = 'none'; void box.offsetWidth; box.style.animation = '';
  return box;
}
function closeModal() { if (!modalOpen) return; modalOpen = false; $('#modal').classList.add('hidden'); const f = modalOnClose; modalOnClose = null; if (f) f(); }
$('#modal').addEventListener('pointerdown', e => { if (e.target.id === 'modal' && modalClosable) { closeModal(); } });

/* ---------- القائمة ---------- */
function refreshMenu() {
  $('#menuStars').textContent = JL.totalStars(); const n = JL.nextLevel(); $('#playLv').textContent = 'المرحلة ' + n;
  $('#dailyDot').classList.toggle('hidden', !dailyReady());
}
$('#btnPlay').onclick = () => { click(); openLevel(JL.nextLevel()); };
$('#btnLevels').onclick = () => { click(); go('levels'); };
$('#btnShop').onclick = () => { click(); go('shop'); };
$('#btnSettings').onclick = () => { click(); go('settings'); };
$('#btnDaily').onclick = () => { click(); openDaily(); };
$('#btnHelp').onclick = () => { click(); openHelp(); };
$$('.back').forEach(b => b.onclick = () => { click(); home('menu'); });

/* ---------- خريطة المراحل ---------- */
function buildMap() {
  const sc = $('#mapScroll'), inner = $('#mapInner'), w = sc.clientWidth || 360, STEP = 104, N = JL.LEVELS, top = 90, hgt = top + (N - 1) * STEP + 150, cur = JL.nextLevel();
  inner.style.height = hgt + 'px';
  const pts = []; for (let i = 1; i <= N; i++) pts.push([w / 2 + Math.sin((i - 1) * .95 + .3) * w * .3, hgt - 90 - (i - 1) * STEP]);
  let d = 'M' + pts[0][0] + ' ' + pts[0][1], dd = d;
  for (let i = 1; i < N; i++) { const a = pts[i - 1], b = pts[i], my = (a[1] + b[1]) / 2, seg = ' C' + a[0] + ' ' + my + ' ' + b[0] + ' ' + my + ' ' + b[0] + ' ' + b[1]; d += seg; if (i < cur) dd += seg; }
  let h = '<svg class="path" viewBox="0 0 ' + w + ' ' + hgt + '"><path d="' + d + '" fill="none" stroke="rgba(0,0,0,.35)" stroke-width="16" stroke-linecap="round"/><path d="' + d + '" fill="none" stroke="rgba(255,255,255,.22)" stroke-width="8" stroke-dasharray="2 16" stroke-linecap="round"/><path d="' + dd + '" fill="none" stroke="#ffc928" stroke-width="8" stroke-linecap="round"/></svg>';
  const names = ['وادي الياقوت', 'بحيرة الزمرد', 'قصر الألماس'];
  [0, 1, 2].forEach(i => { h += '<div class="chapter" style="top:' + (pts[i * 10 + 9][1] - 98) + 'px">' + names[i] + '</div>'; });
  for (let n = 1; n <= N; n++) {
    const st = S().stars[n] || 0, ok = JL.unlocked(n), boss = n % 10 === 0, p = pts[n - 1];
    h += '<button class="node ' + (ok ? '' : 'locked') + ' ' + (n === cur && ok ? 'cur' : '') + ' ' + (boss ? 'boss' : '') + '" data-n="' + n + '" style="left:' + p[0] + 'px;top:' + p[1] + 'px">' + (ok ? (boss ? icon('crown') : '') + n : icon('lock')) +
      (ok && st ? '<span class="st">' + [1, 2, 3].map(i => icon(i <= st ? 'star' : 'starOff')).join('') + '</span>' : '') + '</button>';
  }
  inner.innerHTML = h;
  $$('#mapInner .node').forEach(b => b.onclick = () => { sfx('click'); openLevel(+b.dataset.n); });
  const cp = pts[Math.min(cur, N) - 1]; sc.scrollTop = Math.max(0, cp[1] - sc.clientHeight * .55);
}
const TIPS = { 1: 'اسحب جوهرة نحو جارتها لتبديلهما، وطابق 3 أو أكثر.', 2: 'طابق 4 جواهر في خط لتصنع جوهرة خطية تمسح صفاً أو عموداً كاملاً!', 3: 'طابق 5 في خط لتصنع كرة الألوان السحرية، أو شكل L/T لتصنع قنبلة.', 4: 'اجمع جوهرتين خاصتين معاً لتأثير ضخم!', 5: 'الجليد يتحطم عندما تطابق جواهر فوقه.' };
function openLevel(n) {
  if (n > JL.LEVELS || !JL.unlocked(n)) return; const L = JL.makeLevel(n), tip = TIPS[n];
  modal({
    title: (L.boss ? 'زعيم · ' : '') + 'المرحلة ' + n, gold: L.boss,
    body: '<p>الهدف</p><div class="goalRow">' + L.goals.map(goalChip).join('') + '</div><p>الحركات: <b>' + L.moves + '</b></p>' + (tip ? '<div class="tip">' + icon('spark') + '<span>' + tip + '</span></div>' : ''),
    buttons: [{ t: 'ابدأ', icon: 'play', fn: () => startLevel(n) }, { t: 'رجوع', cls: 'alt', fn: closeModal }]
  });
}
function startLevel(n) {
  closeModal(); JL.audio.duck(false); if (cur !== 'game') go('game');
  requestAnimationFrame(() => requestAnimationFrame(() => { JL.game.setVisible(true); JL.game.start(n); }));
}

/* ---------- النتائج ---------- */
JL.on('win', r => {
  const stars = [1, 2, 3].map(i => icon('star', 'off')).join('');
  modal({
    title: r.last ? 'أنهيت اللعبة!' : 'أحسنت!', gold: true, closable: false,
    body: '<div class="starsRow" id="resStars">' + stars + '</div><p>النقاط: <b id="resScore">0</b></p><div class="rew">' + icon('coin') + '<span>&#x200E;+<b id="resCoins">0</b></span></div>' + (r.last ? '<p>أنت الآن أسطورة الجواهر حقاً!</p>' : ''),
    buttons: [!r.last && { t: 'المرحلة التالية', icon: 'play', fn: () => { closeModal(); openLevel(r.n + 1); } }, { t: 'إعادة المرحلة', cls: 'alt', icon: 'retry', fn: () => { closeModal(); startLevel(r.n); } }, { t: 'الخريطة', cls: 'alt', icon: 'map', fn: () => { closeModal(); home('levels'); go('levels'); } }].filter(Boolean)
  });
  const els = $$('#resStars .ic'); els.forEach((e, i) => { setTimeout(() => { if (!modalOpen) return; if (i < r.stars) { e.setAttribute('class', 'ic on'); e.firstElementChild.setAttribute('href', '#i-star'); sfx('star', i); JL.vib(20); } else { e.firstElementChild.setAttribute('href', '#i-starOff'); e.setAttribute('class', 'ic off'); } }, 450 + i * 480); });
  countUp('#resScore', r.score, 900); countUp('#resCoins', r.coins, 900); coinsRefresh();
});
JL.on('lose', r => {
  const prog = r.goals.map(g => g.k === 'score' ? icon('star') + Math.min(g.cur, g.v) + '/' + g.v : g.k === 'col' ? '<img src="' + JL.gemURL(g.t, 40) + '" width="26" height="26" alt="">' + Math.min(g.cur, g.v) + '/' + g.v : icon('snow') + (g.v - g.cur) + ' متبقي').map(x => '<div class="chip">' + x + '</div>').join('');
  modal({
    title: 'نفدت الحركات', closable: false, body: '<p>اقتربت كثيراً! النقاط: <b>' + r.score + '</b></p><div class="goalRow">' + prog + '</div>',
    buttons: [r.canContinue && { t: '+5 حركات (80)', cls: 'green', icon: 'coin', dis: S().coins < 80, fn: () => { S().coins -= 80; JL.save(); coinsRefresh(); closeModal(); JL.game.continueGame(); } },
      { t: 'إعادة المحاولة', icon: 'retry', fn: () => { closeModal(); startLevel(r.n); } }, { t: 'الخريطة', cls: 'alt', icon: 'map', fn: () => { closeModal(); home('levels'); go('levels'); } }].filter(Boolean)
  });
});
function countUp(sel, to, ms) { const el = $(sel), t0 = performance.now(); (function s(now) { if (!el.isConnected) return; const u = Math.min(1, (now - t0) / ms); el.textContent = Math.round(to * (1 - Math.pow(1 - u, 3))); if (u < 1) requestAnimationFrame(s); })(t0); }

/* ---------- إيقاف مؤقت ---------- */
function pauseMenu() {
  if (!JL.game.state || modalOpen) return; JL.game.pause(true);
  const q = () => { JL.game.pause(false); };
  modal({
    title: 'إيقاف مؤقت', onClose: q,
    body: '<div class="setRow"><span>المؤثرات</span><button class="sw ' + (S().sound ? 'on' : '') + '" data-s="sound"></button></div><div class="setRow"><span>الموسيقى</span><button class="sw ' + (S().music ? 'on' : '') + '" data-s="music"></button></div>',
    buttons: [{ t: 'متابعة', icon: 'play', fn: closeModal }, { t: 'إعادة المرحلة', cls: 'alt', icon: 'retry', fn: () => { modalOnClose = null; closeModal(); JL.game.pause(false); startLevel(JL.game.level); } }, { t: 'الخريطة', cls: 'alt', icon: 'map', fn: () => { modalOnClose = null; closeModal(); home('levels'); go('levels'); } }]
  });
  $$('#modalBox .sw').forEach(wireSwitch);
}
$('#btnPause').onclick = () => { click(); pauseMenu(); };
$('#toolCancel').onclick = () => { click(); JL.game.booster('hammer'); };

/* ---------- المعززات ---------- */
const PRICES = { hammer: 60, shuffle: 50, moves: 90 }, BNAME = { hammer: 'مطرقة التحطيم', shuffle: 'خلط الجواهر', moves: '\u200E+5 حركات' }, BICO = { hammer: 'hammer', shuffle: 'shuffle', moves: 'plus' }, BDESC = { hammer: 'تحطّم أي جوهرة بنقرة', shuffle: 'تعيد ترتيب كل الجواهر', moves: 'خمس حركات إضافية' };
$$('.boost').forEach(b => b.onclick = () => {
  JL.audio.init(); const k = b.dataset.b, r = JL.game.booster(k); if (r === false) return; sfx('click');
  if (r === 'buy') { const st = JL.game.state; if (st) JL.game.pause(true); modal({ title: BNAME[k], onClose: () => JL.game.pause(false), body: '<div class="card" style="margin:0 0 10px"><div class="ci">' + icon(BICO[k]) + '</div><div class="ct">' + BNAME[k] + '<span>' + BDESC[k] + '</span></div></div><p>رصيدك: <b>' + S().coins + '</b></p>', buttons: [{ t: 'شراء (' + PRICES[k] + ')', cls: 'green', icon: 'coin', dis: S().coins < PRICES[k], fn: () => { S().coins -= PRICES[k]; S().inv[k]++; JL.save(); sfx('coin'); coinsRefresh(); JL.game.updateBoosters(); closeModal(); } }, { t: 'إغلاق', cls: 'alt', fn: closeModal }] }); }
});

/* ---------- المتجر ---------- */
function buildShop() {
  let h = '';
  h += '<div class="sec">المعززات</div>';
  ['hammer', 'shuffle', 'moves'].forEach(k => h += '<div class="card"><div class="ci">' + icon(BICO[k]) + '</div><div class="ct">' + BNAME[k] + '<span>' + BDESC[k] + ' · تملك ' + (S().inv[k] || 0) + '</span></div><button class="btn sm" data-buy="' + k + '" ' + (S().coins < PRICES[k] ? 'disabled' : '') + '>' + PRICES[k] + icon('coin') + '</button></div>');
  h += '<div class="sec">الخلفيات</div>';
  JL.THEMES.forEach((t, i) => { const own = S().themes.includes(i), on = S().theme === i; h += '<div class="card"><div class="swatch" style="background:linear-gradient(' + t.c[0] + ',' + t.c[1] + ' 60%,' + t.c[2] + ')"></div><div class="ct">' + t.n + '</div><button class="btn sm ' + (on ? 'alt' : own ? 'green' : '') + '" data-th="' + i + '" ' + ((!own && S().coins < t.price) || on ? 'disabled' : '') + '>' + (on ? 'مفعّلة' : own ? 'استخدم' : t.price + icon('coin')) + '</button></div>'; });
  $('#shopBody').innerHTML = h;
  $$('[data-buy]').forEach(b => b.onclick = () => { const k = b.dataset.buy; if (S().coins >= PRICES[k]) { S().coins -= PRICES[k]; S().inv[k]++; JL.save(); sfx('coin'); coinsRefresh(); buildShop(); } });
  $$('[data-th]').forEach(b => b.onclick = () => { const i = +b.dataset.th, t = JL.THEMES[i]; if (!S().themes.includes(i)) { if (S().coins < t.price) return; S().coins -= t.price; S().themes.push(i); sfx('coin'); } S().theme = i; JL.save(); JL.game.setTheme(i); sfx('click'); coinsRefresh(); buildShop(); });
}

/* ---------- الإعدادات ---------- */
function wireSwitch(s) { s.onclick = () => { const k = s.dataset.s; S()[k] = !S()[k]; JL.save(); s.classList.toggle('on', !!S()[k]); JL.audio.init(); JL.audio.setVolumes(); if (k === 'music') { S().music ? JL.audio.startMusic() : 0; } sfx('click'); }; }
function buildSettings() {
  const sw = (k, ic, t) => '<div class="setRow">' + icon(ic) + '<span>' + t + '</span><button class="sw ' + (S()[k] ? 'on' : '') + '" data-s="' + k + '"></button></div>';
  const sl = (k, ic, t) => '<div class="setRow col"><div class="top">' + icon(ic) + '<span style="flex:1">' + t + '</span></div><input type="range" min="0" max="100" value="' + Math.round(S()[k] * 100) + '" data-v="' + k + '" style="--v:' + Math.round(S()[k] * 100) + '%"></div>';
  const q = S().quality;
  $('#setBody').innerHTML = sw('sound', 'sound', 'المؤثرات الصوتية') + sl('sfxVol', 'sound', 'مستوى المؤثرات') + sw('music', 'music', 'الموسيقى') + sl('musVol', 'music', 'مستوى الموسيقى') + sw('vibe', 'vibe', 'الاهتزاز') + sw('shake', 'shake', 'اهتزاز الشاشة')
    + '<div class="setRow col"><div class="top">' + icon('spark') + '<span style="flex:1">جودة الرسومات</span></div><div class="seg">' + [['auto', 'تلقائي'], ['high', 'عالية'], ['medium', 'متوسطة'], ['low', 'منخفضة']].map(a => '<button data-q="' + a[0] + '" class="' + (q === a[0] ? 'on' : '') + '">' + a[1] + '</button>').join('') + '</div></div>'
    + '<button id="btnReset" class="btn danger" style="width:100%;margin-top:14px">مسح التقدم وإعادة البدء</button><div class="ver">الإصدار 2.0</div>';
  $$('#setBody .sw').forEach(wireSwitch);
  $$('#setBody input[type=range]').forEach(r => { r.oninput = () => { S()[r.dataset.v] = r.value / 100; r.style.setProperty('--v', r.value + '%'); JL.audio.setVolumes(); }; r.onchange = () => { JL.save(); sfx('match', 2); }; });
  $$('#setBody [data-q]').forEach(b => b.onclick = () => { click(); JL.setQualitySetting(b.dataset.q); $$('#setBody [data-q]').forEach(x => x.classList.toggle('on', x === b)); });
  $('#btnReset').onclick = () => modal({ title: 'تأكيد', body: '<p>سيتم مسح كل التقدم والعملات. هل أنت متأكد؟</p>', buttons: [{ t: 'نعم، امسح', cls: 'danger', fn: () => { JL.resetSave(); shownCoins = null; JL.game.setTheme(0); JL.audio.setVolumes(); closeModal(); buildSettings(); coinsRefresh(); JL.toast('تم المسح'); } }, { t: 'إلغاء', cls: 'alt', fn: closeModal }] });
}

/* ---------- المكافأة اليومية ---------- */
const DAILY = [{ c: 50 }, { i: 'hammer', n: 1 }, { c: 100 }, { i: 'shuffle', n: 1 }, { c: 150 }, { i: 'moves', n: 2 }, { c: 300, i: 'hammer', n: 2 }];
const dkey = d => d.getFullYear() + '-' + (d.getMonth() + 1) + '-' + d.getDate();
function dailyState() { const D = S().daily, today = dkey(new Date()), y = new Date(); y.setDate(y.getDate() - 1); let day = D.day; if (D.last && D.last !== today && D.last !== dkey(y)) day = 0; return { today, ready: D.last !== today, day }; }
function dailyReady() { return dailyState().ready; }
function openDaily() {
  const st = dailyState();
  const cells = DAILY.map((r, i) => '<div class="day ' + (i === st.day && st.ready ? 'now' : '') + ' ' + (i < st.day || (i === st.day && !st.ready) ? 'got' : '') + '"><span>يوم ' + (i + 1) + '</span>' + icon(r.i && !r.c ? BICO[r.i] : 'coin') + '<b>' + (r.c ? r.c : '×' + r.n) + (r.c && r.i ? '+' : '') + '</b></div>').join('');
  modal({
    title: 'هدية يومية', gold: true, body: '<p>عُد كل يوم لمكافآت أكبر!</p><div class="days">' + cells + '</div>',
    buttons: [st.ready ? { t: 'استلم', icon: 'gift', cls: 'green', fn: () => claimDaily(st) } : { t: 'عد غداً', cls: 'alt', dis: true }, { t: 'إغلاق', cls: 'alt', fn: closeModal }]
  });
}
function claimDaily(st) {
  const r = DAILY[st.day]; if (r.c) S().coins += r.c; if (r.i) S().inv[r.i] += r.n;
  S().daily = { last: st.today, day: (st.day + 1) % 7 }; JL.save(); sfx('coin'); sfx('special'); JL.vib(30); coinsRefresh(); closeModal(); refreshMenu();
  JL.toast('تم استلام الهدية!');
}

/* ---------- كيف تلعب ---------- */
function openHelp() {
  const row = (img, t) => '<div class="row"><img src="' + img + '" alt=""><span>' + t + '</span></div>';
  modal({
    title: 'كيف تلعب', body: '<div class="how">' + row(JL.gemURL(0, 96), 'اسحب جوهرة نحو جارتها وطابق 3 أو أكثر من اللون نفسه.') + row(JL.specialURL(1, 96), '4 في خط: جوهرة خطية تمسح صفاً كاملاً.') + row(JL.specialURL(2, 96), '4 في عمود: تمسح عموداً كاملاً.') + row(JL.specialURL(3, 96), 'شكل L أو T: قنبلة تنفجر حولها.') + row(JL.specialURL(4, 96), '5 في خط: كرة الألوان، بدّلها مع أي جوهرة لتمسح لونها كله!') + '</div><p>اجمع جوهرتين خاصتين معاً لتأثير مدمّر.</p>',
    buttons: [{ t: 'حسناً', fn: closeModal }]
  });
}

/* ---------- البداية والتحميل ---------- */
async function boot() {
  const bar = $('#loadBar i'), steps = JL.bakeSteps.length + 2; let done = 0; const prog = () => { bar.style.width = Math.round(++done / steps * 100) + '%'; };
  JL.initQuality(); await JL.nextFrame();
  for (const s of JL.bakeSteps) { s[1](); prog(); await JL.nextFrame(); await JL.sleep(30); }
  JL.game.init(); prog(); await JL.nextFrame();
  const logo = JL.bakeLogo(); ['#logoSplash', '#logoMenu'].forEach((id, i) => { const c = i ? JL.mk(logo.width, logo.height) : logo; if (i) c.getContext('2d').drawImage(logo, 0, 0); $(id).appendChild(c); });
  coinsRefresh(); prog(); await JL.sleep(250);
  $('#loadBar').classList.add('hidden'); $('#tapStart').classList.remove('hidden');
}
$('#tapStart').onclick = () => {
  JL.audio.init(); JL.audio.startMusic(); sfx('win'); arm(); show('menu');
  if (dailyReady()) setTimeout(() => { if (cur === 'menu' && !modalOpen) openDaily(); }, 700);
};
document.addEventListener('contextmenu', e => e.preventDefault());
boot();
JL.ui = { show, go, home, modal, closeModal, openLevel, startLevel };
})();
