/* ===========================================================
   أسطورة الجواهر — الجرافيك: خبز (Bake) جواهر مقطوعة بإضاءة حقيقية
   كل الرسومات تُولَّد مرة واحدة عند التحميل ثم تُنسخ كصور سريعة جداً
   =========================================================== */
(function () {
'use strict';
const JL = window.JL, TAU = Math.PI * 2;
const mk = (w, h) => { const c = document.createElement('canvas'); c.width = w; c.height = h || w; return c; };
JL.mk = mk;

/* ---------- ألوان ---------- */
const hex = c => { const n = parseInt(c.slice(1), 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; };
const mixc = (a, b, t) => [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t];
const css = (c, a) => (a === undefined || a === 1) ? 'rgb(' + (c[0] | 0) + ',' + (c[1] | 0) + ',' + (c[2] | 0) + ')' : 'rgba(' + (c[0] | 0) + ',' + (c[1] | 0) + ',' + (c[2] | 0) + ',' + a + ')';
JL.hex = hex; JL.css = css;
const RP = [0, .25, .5, .78, 1];
const rampOf = st => t => { t = t < 0 ? 0 : t > 1 ? 1 : t; for (let i = 1; i < 5; i++) if (t <= RP[i]) return mixc(st[i - 1], st[i], (t - RP[i - 1]) / (RP[i] - RP[i - 1])); return st[4]; };
function rng(seed) { let a = seed >>> 0; return () => { a = (a + 0x6D2B79F5) >>> 0; let t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }

/* ---------- تعريف الجواهر ---------- */
const GDEF = [
  { n: 'ياقوت',       pal: ['#3d0212', '#8d0826', '#e41844', '#ff6f8a', '#ffd6dd'], glow: '#ff3a5c' },
  { n: 'ياقوت أزرق',  pal: ['#051a56', '#0c3299', '#1e72f4', '#68b6ff', '#d6edff'], glow: '#3a8cff' },
  { n: 'زمرد',        pal: ['#02301b', '#07683b', '#10b963', '#53ee9f', '#d0fde4'], glow: '#22e58a' },
  { n: 'توباز',       pal: ['#4a2600', '#9c5a00', '#f7a50c', '#ffd94c', '#fff6c6'], glow: '#ffc21f' },
  { n: 'جمشت',        pal: ['#230a49', '#4e1692', '#9238e3', '#c680ff', '#f1d6ff'], glow: '#b45cff' },
  { n: 'كوارتز وردي', pal: ['#44042a', '#930c5c', '#f22d9f', '#ff82cb', '#ffdcf1'], glow: '#ff4db8' },
];
JL.GEMS = GDEF.map(g => { const p = g.pal.map(hex); return { n: g.n, ramp: rampOf(p), pal: p, glow: hex(g.glow), main: g.pal[2], mainRGB: p[2], hi: p[4] }; });
// ألوان الجسيمات: 6 جواهر + ذهبي + أبيض + جليدي
const PCOL = JL.GEMS.map(g => g.mainRGB).concat([hex('#ffd24a'), hex('#ffffff'), hex('#bfefff')]);

/* ---------- أشكال الجواهر (كل جوهرة بصورة مختلفة لسهولة التمييز) ---------- */
function circle(n, r) { const o = []; for (let i = 0; i < n; i++) { const a = i / n * TAU - Math.PI / 2; o.push([Math.cos(a) * r, Math.sin(a) * r]); } return o; }
function chamfer(pts, k) { const o = [], n = pts.length; for (let i = 0; i < n; i++) { const p = pts[i], a = pts[(i + n - 1) % n], b = pts[(i + 1) % n]; o.push([p[0] + (a[0] - p[0]) * k, p[1] + (a[1] - p[1]) * k]); o.push([p[0] + (b[0] - p[0]) * k, p[1] + (b[1] - p[1]) * k]); } return o; }
function subdiv(pts) { const o = [], n = pts.length; for (let i = 0; i < n; i++) { const a = pts[i], b = pts[(i + 1) % n]; o.push(a, [(a[0] + b[0]) / 2, (a[1] + b[1]) / 2]); } return o; }
function heart(n) { const o = []; for (let i = 0; i < n; i++) { const t = i / n * TAU; o.push([16 * Math.pow(Math.sin(t), 3) / 17.5, -(13 * Math.cos(t) - 5 * Math.cos(2 * t) - 2 * Math.cos(3 * t) - Math.cos(4 * t)) / 17.5]); } return o; }
const SHAPES = [
  () => circle(18, 1),
  () => chamfer([[0, -1.18], [.86, 0], [0, 1.18], [-.86, 0]], .1),
  () => subdiv(circle(6, 1.04)),
  () => chamfer([[-.86, -.86], [.86, -.86], [.86, .86], [-.86, .86]], .3),
  () => subdiv(chamfer([[0, -1.1], [1.02, .8], [-1.02, .8]], .2)),
  () => heart(22),
];
const SHAPE_SC = [1, .96, .97, 1, .94, 1.02];

/* ---------- نجمة لامعة (وميض) ---------- */
function bakeStar(S, col) {
  const c = mk(S), x = c.getContext('2d'), m = S / 2, rgb = col || [255, 255, 255];
  const g = x.createRadialGradient(m, m, 0, m, m, m);
  g.addColorStop(0, css(rgb, 1)); g.addColorStop(.1, css(rgb, .7)); g.addColorStop(.35, css(rgb, .14)); g.addColorStop(1, css(rgb, 0));
  x.fillStyle = g; x.fillRect(0, 0, S, S);
  x.fillStyle = css(mixc(rgb, [255, 255, 255], .6));
  const k = S * .045;
  x.beginPath(); x.moveTo(m, 0); x.quadraticCurveTo(m + k, m - k, S, m); x.quadraticCurveTo(m + k, m + k, m, S); x.quadraticCurveTo(m - k, m + k, 0, m); x.quadraticCurveTo(m - k, m - k, m, 0); x.fill();
  x.globalAlpha = .8; x.beginPath(); const d = S * .22, k2 = S * .02;
  x.moveTo(m + d, m - d); x.quadraticCurveTo(m + k2, m - k2, m - d, m + d); x.quadraticCurveTo(m - k2, m + k2, m + d, m - d); x.fill();
  x.beginPath(); x.moveTo(m - d, m - d); x.quadraticCurveTo(m + k2, m + k2, m + d, m + d); x.quadraticCurveTo(m - k2, m - k2, m - d, m - d); x.fill();
  return c;
}
let STAR = null;

/* ---------- جوهرة مقطوعة (Brilliant) بإضاءة حقيقية ---------- */
const LV = (() => { const n = v => { const l = Math.hypot(v[0], v[1], v[2]); return [v[0] / l, v[1] / l, v[2] / l]; }; const L = n([-.55, -.7, .62]); return { L, H: n([L[0], L[1], L[2] + 1]), L2: n([.7, .55, .5]) }; })();
function bakeGem(type, S) {
  const gm = JL.GEMS[type], ramp = gm.ramp, R = S * .37 * SHAPE_SC[type];
  const poly = SHAPES[type](), N = poly.length;
  let mnx = 9, mxx = -9, mny = 9, mxy = -9, cx0 = 0, cy0 = 0;
  poly.forEach(p => { mnx = Math.min(mnx, p[0]); mxx = Math.max(mxx, p[0]); mny = Math.min(mny, p[1]); mxy = Math.max(mxy, p[1]); cx0 += p[0]; cy0 += p[1]; });
  const bx = (mnx + mxx) / 2, by = (mny + mxy) / 2; cx0 /= N; cy0 /= N;
  const P = poly.map(p => [S / 2 + (p[0] - bx) * R, S / 2 + (p[1] - by) * R]);
  const C = [S / 2 + (cx0 - bx) * R, S / 2 + (cy0 - by) * R];
  const M = [], T = [];
  for (let i = 0; i < N; i++) {
    const a = P[i], b = P[(i + 1) % N];
    M.push([C[0] + ((a[0] + b[0]) / 2 - C[0]) * .70, C[1] + ((a[1] + b[1]) / 2 - C[1]) * .70]);
    T.push([C[0] + (a[0] - C[0]) * .46, C[1] + (a[1] - C[1]) * .46]);
  }
  const gc = mk(S), x = gc.getContext('2d'), rnd = rng(type * 977 + 13);
  x.lineJoin = 'round'; x.lineCap = 'round';
  const path = pts => { x.beginPath(); pts.forEach((p, i) => i ? x.lineTo(p[0], p[1]) : x.moveTo(p[0], p[1])); x.closePath(); };

  // سماكة الجوهرة (جانبها السفلي)
  const th = S * .034;
  x.save(); x.translate(0, th); path(P);
  let g = x.createLinearGradient(0, S * .3, 0, S * .8); g.addColorStop(0, css(ramp(.18))); g.addColorStop(1, css(ramp(.02)));
  x.fillStyle = g; x.fill(); x.strokeStyle = css(ramp(0)); x.lineWidth = S * .02; x.stroke(); x.restore();
  path(P); x.fillStyle = css(ramp(.5)); x.fill();

  // الوجوه: 4 مثلثات لكل ضلع (قطع لامع)
  const tris = [];
  for (let i = 0; i < N; i++) {
    const j = (i + 1) % N;
    tris.push([P[i], P[j], M[i], .90], [P[j], M[i], M[j], .74], [M[i], M[j], T[j], .54], [T[i], T[j], M[i], .36]);
  }
  tris.forEach(tr => {
    const a = tr[0], b = tr[1], c = tr[2];
    const cx = (a[0] + b[0] + c[0]) / 3, cy = (a[1] + b[1] + c[1]) / 3;
    let dx = cx - C[0], dy = cy - C[1]; const dl = Math.hypot(dx, dy) || 1; dx /= dl; dy /= dl;
    const k = Math.min(.97, tr[3] + (rnd() - .5) * .16), nz = Math.sqrt(1 - k * k), nx = dx * k, ny = dy * k;
    const diff = Math.max(0, nx * LV.L[0] + ny * LV.L[1] + nz * LV.L[2]);
    const sp = Math.pow(Math.max(0, nx * LV.H[0] + ny * LV.H[1] + nz * LV.H[2]), 56);
    const rim = Math.max(0, nx * LV.L2[0] + ny * LV.L2[1] + nz * LV.L2[2]);
    let t = .06 + .72 * Math.pow(diff, .85) + .22 * rim;
    if (rnd() < .11) t += .17;
    t = JL.clamp(t, 0, 1);
    const rr = Math.max(Math.hypot(a[0] - cx, a[1] - cy), Math.hypot(b[0] - cx, b[1] - cy), Math.hypot(c[0] - cx, c[1] - cy));
    const s = (dx * LV.L[0] + dy * LV.L[1]) > 0 ? 1 : -1;
    const gr = x.createLinearGradient(cx - dx * rr, cy - dy * rr, cx + dx * rr, cy + dy * rr);
    gr.addColorStop(0, css(ramp(t - .11 * s))); gr.addColorStop(1, css(ramp(t + .11 * s)));
    path([a, b, c]); x.fillStyle = gr; x.fill();
    x.strokeStyle = css(ramp(t)); x.lineWidth = .9; x.stroke();
    if (sp > .04) { path([a, b, c]); x.fillStyle = 'rgba(255,255,255,' + Math.min(.88, sp * .95) + ')'; x.fill(); }
  });
  // حواف الوجوه
  x.lineWidth = S * .005; x.strokeStyle = 'rgba(255,255,255,.2)';
  for (let i = 0; i < N; i++) { const j = (i + 1) % N; x.beginPath(); x.moveTo(P[i][0], P[i][1]); x.lineTo(M[i][0], M[i][1]); x.lineTo(P[j][0], P[j][1]); x.moveTo(M[i][0], M[i][1]); x.lineTo(M[j][0], M[j][1]); x.moveTo(M[i][0], M[i][1]); x.lineTo(T[i][0], T[i][1]); x.moveTo(M[i][0], M[i][1]); x.lineTo(T[j][0], T[j][1]); x.stroke(); }
  x.strokeStyle = 'rgba(0,0,0,.16)'; path(M); x.stroke();

  // سطح الجوهرة (Table) + انعكاس الوجوه الداخلية
  path(T); g = x.createLinearGradient(C[0] - R * .5, C[1] - R * .5, C[0] + R * .5, C[1] + R * .5);
  g.addColorStop(0, css(ramp(.86))); g.addColorStop(.55, css(ramp(.55))); g.addColorStop(1, css(ramp(.3)));
  x.fillStyle = g; x.fill();
  const LA = Math.atan2(LV.L[1], LV.L[0]);
  for (let i = 0; i < N; i++) {
    const j = (i + 1) % N, ma = Math.atan2((T[i][1] + T[j][1]) / 2 - C[1], (T[i][0] + T[j][0]) / 2 - C[0]), sh = Math.cos(ma - LA);
    path([C, T[i], T[j]]);
    x.fillStyle = sh > 0 ? 'rgba(255,255,255,' + sh * .26 + ')' : 'rgba(0,0,0,' + (-sh) * .34 + ')'; x.fill();
  }
  x.strokeStyle = 'rgba(255,255,255,.28)'; x.lineWidth = S * .006;
  for (let i = 0; i < N; i += 1) { x.beginPath(); x.moveTo(C[0], C[1]); x.lineTo(T[i][0], T[i][1]); x.stroke(); }
  x.strokeStyle = 'rgba(255,255,255,.5)'; x.lineWidth = S * .008; path(T); x.stroke();
  // لمعان على السطح
  x.save(); path(T); x.clip();
  g = x.createLinearGradient(C[0] - R * .6, C[1] - R * .6, C[0] + R * .4, C[1] + R * .4);
  g.addColorStop(0, 'rgba(255,255,255,.7)'); g.addColorStop(.32, 'rgba(255,255,255,.18)'); g.addColorStop(.36, 'rgba(255,255,255,0)'); g.addColorStop(.52, 'rgba(255,255,255,.14)'); g.addColorStop(.58, 'rgba(255,255,255,0)');
  x.fillStyle = g; x.fillRect(0, 0, S, S); x.restore();

  // توهج داخلي بلون الجوهرة
  x.save(); path(P); x.clip(); x.globalCompositeOperation = 'lighter';
  g = x.createRadialGradient(C[0], C[1] + R * .15, 0, C[0], C[1] + R * .15, R * .95);
  g.addColorStop(0, css(gm.glow, .34)); g.addColorStop(1, css(gm.glow, 0)); x.fillStyle = g; x.fillRect(0, 0, S, S); x.restore();

  // إضاءة الحواف
  for (let i = 0; i < N; i++) {
    const j = (i + 1) % N, a = P[i], b = P[j], mx = (a[0] + b[0]) / 2 - C[0], my = (a[1] + b[1]) / 2 - C[1], ml = Math.hypot(mx, my) || 1;
    const f = (mx / ml) * LV.L[0] / Math.hypot(LV.L[0], LV.L[1]) + (my / ml) * LV.L[1] / Math.hypot(LV.L[0], LV.L[1]);
    const sh = .985; x.beginPath(); x.moveTo(C[0] + (a[0] - C[0]) * sh, C[1] + (a[1] - C[1]) * sh); x.lineTo(C[0] + (b[0] - C[0]) * sh, C[1] + (b[1] - C[1]) * sh);
    if (f > .3) { x.strokeStyle = 'rgba(255,255,255,' + Math.min(.85, f * .75) + ')'; x.lineWidth = S * .017; x.stroke(); }
    else if (f < -.3) { x.strokeStyle = css(ramp(0), Math.min(.6, -f * .6)); x.lineWidth = S * .02; x.stroke(); }
  }
  path(P); x.strokeStyle = css(ramp(0), .9); x.lineWidth = S * .026; x.stroke();
  // وميض ناعم + نجمتان
  x.save(); path(P); x.clip();
  g = x.createRadialGradient(C[0] - R * .4, C[1] - R * .45, 0, C[0] - R * .4, C[1] - R * .45, R * .55);
  g.addColorStop(0, 'rgba(255,255,255,.55)'); g.addColorStop(1, 'rgba(255,255,255,0)'); x.fillStyle = g; x.fillRect(0, 0, S, S); x.restore();
  if (!STAR) STAR = bakeStar(128);
  x.save(); x.globalCompositeOperation = 'lighter';
  x.globalAlpha = .9; x.drawImage(STAR, C[0] - R * .42 - S * .135, C[1] - R * .48 - S * .135, S * .27, S * .27);
  x.globalAlpha = .6; x.drawImage(STAR, C[0] + R * .4 - S * .08, C[1] + R * .34 - S * .08, S * .16, S * .16); x.restore();

  const out = mk(S), ox = out.getContext('2d');
  ox.shadowColor = 'rgba(0,0,0,.5)'; ox.shadowBlur = S * .05; ox.shadowOffsetY = S * .028; ox.drawImage(gc, 0, 0);
  return out;
}

/* ---------- كرة الألوان السحرية ---------- */
function bakeOrbDisk(S) {
  const c = mk(S), x = c.getContext('2d'), m = S / 2, R = S * .36;
  x.save(); x.beginPath(); x.arc(m, m, R, 0, TAU); x.clip();
  for (let i = 0; i < 6; i++) {
    const gm = JL.GEMS[i], a0 = i * TAU / 6, a1 = (i + 1) * TAU / 6 + .02;
    const g = x.createRadialGradient(m, m, 0, m, m, R); g.addColorStop(0, css(gm.ramp(.95))); g.addColorStop(.5, css(gm.ramp(.62))); g.addColorStop(1, css(gm.ramp(.38)));
    x.beginPath(); x.moveTo(m, m); x.arc(m, m, R * 1.1, a0, a1); x.closePath(); x.fillStyle = g; x.fill();
  }
  x.strokeStyle = 'rgba(255,255,255,.42)'; x.lineWidth = S * .012;
  for (let i = 0; i < 6; i++) { const a = i * TAU / 6; x.beginPath(); x.moveTo(m, m); x.quadraticCurveTo(m + Math.cos(a + .5) * R * .6, m + Math.sin(a + .5) * R * .6, m + Math.cos(a + .2) * R, m + Math.sin(a + .2) * R); x.stroke(); }
  x.restore(); return c;
}
function bakeOrbGlass(S) {
  const c = mk(S), x = c.getContext('2d'), m = S / 2, R = S * .36;
  let g = x.createRadialGradient(m - R * .25, m - R * .3, R * .1, m, m, R);
  g.addColorStop(0, 'rgba(255,255,255,.28)'); g.addColorStop(.55, 'rgba(255,255,255,0)'); g.addColorStop(.88, 'rgba(10,0,40,.28)'); g.addColorStop(1, 'rgba(10,0,40,.62)');
  x.beginPath(); x.arc(m, m, R, 0, TAU); x.fillStyle = g; x.fill();
  x.save(); x.beginPath(); x.arc(m, m, R, 0, TAU); x.clip();
  g = x.createLinearGradient(m - R, m - R, m + R * .2, m); g.addColorStop(0, 'rgba(255,255,255,.75)'); g.addColorStop(1, 'rgba(255,255,255,0)');
  x.fillStyle = g; x.beginPath(); x.ellipse(m - R * .32, m - R * .5, R * .5, R * .24, -.6, 0, TAU); x.fill();
  g = x.createRadialGradient(m + R * .3, m + R * .55, 0, m + R * .3, m + R * .55, R * .6); g.addColorStop(0, 'rgba(255,255,255,.38)'); g.addColorStop(1, 'rgba(255,255,255,0)'); x.fillStyle = g; x.fillRect(0, 0, S, S);
  x.restore();
  x.lineWidth = S * .022; x.strokeStyle = 'rgba(255,255,255,.9)'; x.beginPath(); x.arc(m, m, R, 0, TAU); x.stroke();
  x.lineWidth = S * .012; x.strokeStyle = 'rgba(255,215,90,.9)'; x.beginPath(); x.arc(m, m, R + S * .02, 0, TAU); x.stroke();
  x.save(); x.globalCompositeOperation = 'lighter'; if (!STAR) STAR = bakeStar(128); x.drawImage(STAR, m - R * .5 - S * .11, m - R * .55 - S * .11, S * .22, S * .22); x.restore();
  return c;
}
/* ---------- خطوط السهم (جوهرة خطية) ---------- */
function bakeArrows(S) {
  const c = mk(S), x = c.getContext('2d'), m = S / 2;
  x.shadowColor = 'rgba(255,200,60,.95)'; x.shadowBlur = S * .06; x.lineJoin = 'round';
  const g = x.createLinearGradient(0, m - S * .2, 0, m + S * .2); g.addColorStop(0, '#ffffff'); g.addColorStop(1, '#ffe9a0');
  x.fillStyle = g; x.strokeStyle = '#9a5200'; x.lineWidth = S * .016;
  x.beginPath(); x.rect(S * .27, m - S * .022, S * .46, S * .044); x.fill(); x.stroke();
  for (const d of [-1, 1]) { x.beginPath(); x.moveTo(m + d * S * .43, m); x.lineTo(m + d * S * .26, m - S * .115); x.lineTo(m + d * S * .26, m + S * .115); x.closePath(); x.fill(); x.stroke(); }
  return c;
}
/* ---------- حلقة القنبلة ---------- */
function bakeBombRing(S) {
  const c = mk(S), x = c.getContext('2d'), m = S / 2;
  x.shadowColor = 'rgba(255,170,30,.95)'; x.shadowBlur = S * .06; x.lineJoin = 'round';
  const g = x.createLinearGradient(0, 0, S, S); g.addColorStop(0, '#fff6b8'); g.addColorStop(.5, '#ffc21f'); g.addColorStop(1, '#d98200');
  x.strokeStyle = g; x.lineWidth = S * .035; x.beginPath(); x.arc(m, m, S * .335, 0, TAU); x.stroke();
  x.fillStyle = g;
  for (let i = 0; i < 8; i++) { const a = i * Math.PI / 4; x.save(); x.translate(m, m); x.rotate(a); x.beginPath(); x.moveTo(S * .325, -S * .045); x.lineTo(S * .445, 0); x.lineTo(S * .325, S * .045); x.closePath(); x.fill(); x.strokeStyle = '#8a4a00'; x.lineWidth = S * .008; x.stroke(); x.restore(); }
  x.shadowBlur = 0; x.strokeStyle = 'rgba(255,255,255,.85)'; x.lineWidth = S * .008; x.beginPath(); x.arc(m, m, S * .31, 0, TAU); x.stroke();
  return c;
}
/* ---------- بلاطة الجليد ---------- */
function bakeIce(S, layers) {
  const c = mk(S), x = c.getContext('2d'), r = rng(layers * 31 + 7), p = S * .03, w = S - p * 2, rad = S * .16;
  const rr = (a, b, ww, hh, rd) => { x.beginPath(); x.moveTo(a + rd, b); x.arcTo(a + ww, b, a + ww, b + hh, rd); x.arcTo(a + ww, b + hh, a, b + hh, rd); x.arcTo(a, b + hh, a, b, rd); x.arcTo(a, b, a + ww, b, rd); x.closePath(); };
  let g = x.createLinearGradient(0, 0, S, S);
  if (layers > 1) { g.addColorStop(0, 'rgba(235,250,255,.78)'); g.addColorStop(.5, 'rgba(160,210,255,.62)'); g.addColorStop(1, 'rgba(110,170,240,.7)'); }
  else { g.addColorStop(0, 'rgba(235,250,255,.5)'); g.addColorStop(.5, 'rgba(170,220,255,.28)'); g.addColorStop(1, 'rgba(120,185,250,.4)'); }
  rr(p, p, w, w, rad); x.fillStyle = g; x.fill();
  x.save(); rr(p, p, w, w, rad); x.clip();
  for (let i = 0; i < 70; i++) { x.fillStyle = 'rgba(255,255,255,' + (.06 + r() * .18) + ')'; const s = S * (.008 + r() * .02); x.fillRect(r() * S, r() * S, s, s); }
  x.strokeStyle = 'rgba(255,255,255,.55)'; x.lineWidth = S * .012;
  const cracks = layers > 1 ? 5 : 2;
  for (let i = 0; i < cracks; i++) { let px = r() * S, py = r() * S; x.beginPath(); x.moveTo(px, py); for (let k = 0; k < 4; k++) { px += (r() - .5) * S * .28; py += (r() - .3) * S * .26; x.lineTo(px, py); } x.stroke(); }
  g = x.createLinearGradient(0, 0, S * .7, S * .7); g.addColorStop(0, 'rgba(255,255,255,.65)'); g.addColorStop(.35, 'rgba(255,255,255,.12)'); g.addColorStop(.4, 'rgba(255,255,255,0)'); x.fillStyle = g; x.fillRect(0, 0, S, S);
  x.restore();
  x.lineWidth = S * (layers > 1 ? .05 : .035); x.strokeStyle = layers > 1 ? 'rgba(255,255,255,.98)' : 'rgba(255,255,255,.82)'; rr(p, p, w, w, rad); x.stroke();
  x.lineWidth = S * .014; x.strokeStyle = 'rgba(70,140,230,.7)'; rr(p + S * .035, p + S * .035, w - S * .07, w - S * .07, rad * .8); x.stroke();
  if (!STAR) STAR = bakeStar(128);
  x.save(); x.globalCompositeOperation = 'lighter'; x.globalAlpha = .9; x.drawImage(STAR, S * .06, S * .06, S * .3, S * .3); x.restore();
  return c;
}
/* ---------- مطرقة ---------- */
function bakeHammer(S) {
  const c = mk(S), x = c.getContext('2d'), m = S / 2; x.lineJoin = 'round'; x.lineCap = 'round';
  x.shadowColor = 'rgba(0,0,0,.5)'; x.shadowBlur = S * .04; x.shadowOffsetY = S * .02;
  let g = x.createLinearGradient(m - S * .05, 0, m + S * .05, 0); g.addColorStop(0, '#c98340'); g.addColorStop(.5, '#e8a85c'); g.addColorStop(1, '#8a4a1c');
  x.fillStyle = g; x.strokeStyle = '#4a2208'; x.lineWidth = S * .015;
  x.beginPath(); x.roundRect ? x.roundRect(m - S * .05, S * .3, S * .1, S * .6, S * .03) : x.rect(m - S * .05, S * .3, S * .1, S * .6); x.fill(); x.stroke();
  g = x.createLinearGradient(0, S * .12, 0, S * .4); g.addColorStop(0, '#f4f7ff'); g.addColorStop(.45, '#aab6d0'); g.addColorStop(1, '#5d6a8a');
  x.fillStyle = g; x.strokeStyle = '#262e48'; x.lineWidth = S * .018;
  x.beginPath(); x.roundRect ? x.roundRect(S * .16, S * .14, S * .68, S * .26, S * .06) : x.rect(S * .16, S * .14, S * .68, S * .26); x.fill(); x.stroke();
  x.shadowBlur = 0; x.fillStyle = '#ffc928'; x.fillRect(S * .2, S * .14, S * .06, S * .26); x.fillRect(S * .74, S * .14, S * .06, S * .26);
  x.fillStyle = 'rgba(255,255,255,.7)'; x.fillRect(S * .3, S * .17, S * .4, S * .02);
  return c;
}

/* ---------- جسيمات ---------- */
const SPL = [], SPI = { dot: [], shard: [], conf: [], star: 0, starGold: 0, ring: 0 };
function addSp(c) { SPL.push(c); return SPL.length - 1; }
function bakeParticles() {
  PCOL.forEach((col, i) => {
    let c = mk(48), x = c.getContext('2d'), g = x.createRadialGradient(24, 24, 0, 24, 24, 24);
    g.addColorStop(0, 'rgba(255,255,255,1)'); g.addColorStop(.25, css(mixc(col, [255, 255, 255], .45), .95)); g.addColorStop(.6, css(col, .35)); g.addColorStop(1, css(col, 0));
    x.fillStyle = g; x.fillRect(0, 0, 48, 48); SPI.dot[i] = addSp(c);
    for (let v = 0; v < 2; v++) {
      c = mk(40); x = c.getContext('2d'); const pts = v ? [[20, 2], [37, 26], [10, 37], [4, 14]] : [[4, 6], [36, 12], [22, 38]];
      g = x.createLinearGradient(0, 0, 40, 40); g.addColorStop(0, css(mixc(col, [255, 255, 255], .75))); g.addColorStop(.5, css(col)); g.addColorStop(1, css(mixc(col, [0, 0, 0], .45)));
      x.beginPath(); pts.forEach((p, k) => k ? x.lineTo(p[0], p[1]) : x.moveTo(p[0], p[1])); x.closePath(); x.fillStyle = g; x.fill(); x.strokeStyle = 'rgba(255,255,255,.6)'; x.lineWidth = 1.5; x.stroke();
      SPI.shard[i * 2 + v] = addSp(c);
    }
    c = mk(24, 16); x = c.getContext('2d'); g = x.createLinearGradient(0, 0, 0, 16); g.addColorStop(0, css(mixc(col, [255, 255, 255], .5))); g.addColorStop(1, css(col)); x.fillStyle = g; x.fillRect(0, 0, 24, 16); SPI.conf[i] = addSp(c);
  });
  SPI.star = addSp(bakeStar(96)); SPI.starGold = addSp(bakeStar(96, [255, 214, 90]));
  const c = mk(96), x = c.getContext('2d'); x.lineWidth = 6; const g = x.createRadialGradient(48, 48, 30, 48, 48, 46); g.addColorStop(0, 'rgba(255,255,255,0)'); g.addColorStop(.7, 'rgba(255,255,255,.9)'); g.addColorStop(1, 'rgba(255,255,255,0)'); x.fillStyle = g; x.fillRect(0, 0, 96, 96); SPI.ring = addSp(c);
}
JL.SP = { list: SPL, I: SPI };

/* ---------- تغيير الحجم بجودة عالية (نصف تدريجي) ---------- */
function scaleTo(src, px) {
  let c = src;
  while (c.width / 2 >= px) { const n = mk(Math.round(c.width / 2)), x = n.getContext('2d'); x.imageSmoothingQuality = 'high'; x.drawImage(c, 0, 0, n.width, n.width); c = n; }
  const f = mk(px), x = f.getContext('2d'); x.imageSmoothingQuality = 'high'; x.drawImage(c, 0, 0, px, px); return f;
}
JL.scaleTo = scaleTo;

/* ---------- المجموعة الرئيسية (ماستر 256) ---------- */
const MASTER = { gem: [], glow: [] };
JL.MASTER = MASTER;
function bakeGlow(col, S) {
  const c = mk(S), x = c.getContext('2d'), g = x.createRadialGradient(S / 2, S / 2, 0, S / 2, S / 2, S / 2);
  g.addColorStop(0, css(col, .95)); g.addColorStop(.35, css(col, .42)); g.addColorStop(1, css(col, 0)); x.fillStyle = g; x.fillRect(0, 0, S, S); return c;
}
JL.bakeSteps = [
  ['الجواهر', () => { for (let i = 0; i < 6; i++) MASTER.gem[i] = bakeGem(i, 256); }],
  ['المؤثرات', () => { MASTER.orbDisk = bakeOrbDisk(256); MASTER.orbGlass = bakeOrbGlass(256); MASTER.arrows = bakeArrows(256); MASTER.ring = bakeBombRing(256); MASTER.ice1 = bakeIce(128, 1); MASTER.ice2 = bakeIce(128, 2); MASTER.hammer = bakeHammer(256); for (let i = 0; i < 6; i++) MASTER.glow[i] = bakeGlow(JL.GEMS[i].glow, 128); MASTER.glowGold = bakeGlow([255, 205, 70], 128); MASTER.glowWhite = bakeGlow([255, 255, 255], 128); }],
  ['الجسيمات', () => bakeParticles()],
];

/* ---------- أيقونات HTML من الجواهر ---------- */
const urlCache = {};
JL.gemURL = (t, px) => { const k = t + '_' + (px || 72); if (!urlCache[k]) urlCache[k] = scaleTo(MASTER.gem[t], px || 72).toDataURL(); return urlCache[k]; };
JL.specialURL = (kind, px) => {
  const k = 's' + kind + '_' + (px || 84); if (urlCache[k]) return urlCache[k];
  const S = px || 84, c = mk(S), x = c.getContext('2d');
  x.drawImage(MASTER.glowGold, 0, 0, S, S);
  if (kind === 4) { x.drawImage(scaleTo(MASTER.orbDisk, S), 0, 0); x.drawImage(scaleTo(MASTER.orbGlass, S), 0, 0); }
  else {
    x.drawImage(scaleTo(MASTER.gem[1], S), 0, 0);
    if (kind === 3) x.drawImage(scaleTo(MASTER.ring, S), 0, 0);
    else { x.save(); x.translate(S / 2, S / 2); if (kind === 2) x.rotate(Math.PI / 2); x.drawImage(scaleTo(MASTER.arrows, S), -S / 2, -S / 2); x.restore(); }
  }
  return (urlCache[k] = c.toDataURL());
};

/* ---------- الشعار (مجموعة جواهر فوق توهج) ---------- */
JL.bakeLogo = () => {
  const W = 560, H = 420, c = mk(W, H), x = c.getContext('2d'), cx = W / 2, cy = H * .52;
  let g = x.createRadialGradient(cx, cy, 0, cx, cy, H * .5); g.addColorStop(0, 'rgba(255,214,110,.75)'); g.addColorStop(.45, 'rgba(255,160,60,.22)'); g.addColorStop(1, 'rgba(255,160,60,0)'); x.fillStyle = g; x.fillRect(0, 0, W, H);
  x.save(); x.translate(cx, cy); x.globalCompositeOperation = 'lighter';
  for (let i = 0; i < 14; i++) { x.rotate(TAU / 14); g = x.createLinearGradient(0, 0, H * .5, 0); g.addColorStop(0, 'rgba(255,230,150,.30)'); g.addColorStop(1, 'rgba(255,230,150,0)'); x.fillStyle = g; x.beginPath(); x.moveTo(0, 0); x.lineTo(H * .5, -12); x.lineTo(H * .5, 12); x.closePath(); x.fill(); }
  x.restore();
  const put = (t, dx, dy, s, rot) => { x.save(); x.translate(cx + dx, cy + dy); x.rotate(rot); x.drawImage(MASTER.gem[t], -s / 2, -s / 2, s, s); x.restore(); };
  put(3, 0, -120, 170, 0); put(4, 168, -52, 175, .3); put(5, -168, -52, 175, -.3);
  put(2, 146, 70, 170, .12); put(1, -146, 70, 170, -.12); put(0, 0, 20, 270, 0);
  if (!STAR) STAR = bakeStar(128);
  x.globalCompositeOperation = 'lighter';
  [[-80, -90, 90], [76, -64, 70], [8, 28, 110], [-170, 40, 60], [180, 52, 56], [-36, 150, 64]].forEach(a => x.drawImage(STAR, cx + a[0] - a[2] / 2, cy + a[1] - a[2] / 2, a[2], a[2]));
  return c;
};

/* ================= الخلفيات ================= */
function blobSprite(col) { const S = 256, c = mk(S), x = c.getContext('2d'), g = x.createRadialGradient(S / 2, S / 2, 0, S / 2, S / 2, S / 2); const r = hex(col); g.addColorStop(0, css(r, .85)); g.addColorStop(.5, css(r, .3)); g.addColorStop(1, css(r, 0)); x.fillStyle = g; x.fillRect(0, 0, S, S); return c; }
function raysSprite(col) { const S = 512, c = mk(S), x = c.getContext('2d'), r = hex(col); x.translate(S / 2, S / 2); for (let i = 0; i < 9; i++) { x.rotate(TAU / 9); const g = x.createLinearGradient(0, 0, S / 2, 0); g.addColorStop(0, css(r, .5)); g.addColorStop(1, css(r, 0)); x.fillStyle = g; x.beginPath(); x.moveTo(0, 0); x.lineTo(S / 2, -S * .035); x.lineTo(S / 2, S * .035); x.closePath(); x.fill(); } return c; }
function crystal(x, bx, by, w, h, tint, flip) {
  x.save(); x.translate(bx, by); if (flip) x.scale(1, -1);
  const t = hex(tint), L = mixc(t, [255, 255, 255], .35), D = mixc(t, [0, 0, 0], .5);
  const pts = [[-w / 2, 0], [-w / 2, -h * .7], [0, -h], [w / 2, -h * .7], [w / 2, 0]];
  let g = x.createLinearGradient(-w / 2, 0, w / 2, 0); g.addColorStop(0, css(D, .85)); g.addColorStop(.5, css(t, .75)); g.addColorStop(1, css(L, .8));
  x.beginPath(); pts.forEach((p, i) => i ? x.lineTo(p[0], p[1]) : x.moveTo(p[0], p[1])); x.closePath(); x.fillStyle = g; x.fill();
  x.beginPath(); x.moveTo(0, 0); x.lineTo(0, -h); x.lineTo(w / 2, -h * .7); x.lineTo(w / 2, 0); x.closePath(); x.fillStyle = 'rgba(255,255,255,.12)'; x.fill();
  x.beginPath(); x.moveTo(-w / 2, -h * .7); x.lineTo(0, -h); x.lineTo(0, -h * .7); x.closePath(); x.fillStyle = 'rgba(255,255,255,.2)'; x.fill();
  x.strokeStyle = css(L, .5); x.lineWidth = 1.2; x.beginPath(); pts.forEach((p, i) => i ? x.lineTo(p[0], p[1]) : x.moveTo(p[0], p[1])); x.stroke();
  x.restore();
}
JL.bakeBG = (theme, w, h) => {
  const T = JL.THEMES[theme], s = Math.min(1, 900 / Math.max(w, h)), W = Math.max(2, Math.round(w * s)), H = Math.max(2, Math.round(h * s));
  const c = mk(W, H), x = c.getContext('2d');
  let g = x.createLinearGradient(0, 0, 0, H); g.addColorStop(0, T.c[0]); g.addColorStop(.55, T.c[1]); g.addColorStop(1, T.c[2]); x.fillStyle = g; x.fillRect(0, 0, W, H);
  g = x.createRadialGradient(W / 2, H * .38, 0, W / 2, H * .38, Math.max(W, H) * .65); g.addColorStop(0, 'rgba(255,255,255,.1)'); g.addColorStop(1, 'rgba(255,255,255,0)'); x.fillStyle = g; x.fillRect(0, 0, W, H);
  const r = rng(theme * 53 + 5), n = Math.max(5, Math.round(W / 70));
  for (let i = 0; i < n; i++) { const w2 = (22 + r() * 40) * s * 1.6, h2 = (70 + r() * 160) * s * 1.6; crystal(x, (i + .2 + r() * .6) / n * W, H + 8 * s, w2, h2, T.blob[i % 3], false); }
  for (let i = 0; i < Math.round(n * .6); i++) { const w2 = (14 + r() * 26) * s * 1.6, h2 = (40 + r() * 90) * s * 1.6; crystal(x, (i + .2 + r() * .6) / (n * .6) * W, -6 * s, w2, h2, T.blob[(i + 1) % 3], true); }
  g = x.createRadialGradient(W / 2, H / 2, Math.min(W, H) * .35, W / 2, H / 2, Math.max(W, H) * .75); g.addColorStop(0, 'rgba(0,0,0,0)'); g.addColorStop(1, 'rgba(0,0,0,.5)'); x.fillStyle = g; x.fillRect(0, 0, W, H);
  g = x.createLinearGradient(0, H * .6, 0, H); g.addColorStop(0, 'rgba(0,0,0,0)'); g.addColorStop(1, 'rgba(0,0,0,.35)'); x.fillStyle = g; x.fillRect(0, H * .6, W, H * .4);
  return c;
};
JL.bakeBGSprites = theme => {
  const T = JL.THEMES[theme];
  const o = { blobs: T.blob.map(blobSprite), rays: raysSprite(T.blob[0]), mote: null };
  const accent = hex(T.accent);
  let c = mk(48), x = c.getContext('2d'), g = x.createRadialGradient(24, 24, 0, 24, 24, 24);
  if (T.mote === 'bubble') {
    x.strokeStyle = css(accent, .75); x.lineWidth = 2.5; x.beginPath(); x.arc(24, 24, 19, 0, TAU); x.stroke();
    g.addColorStop(0, css(accent, 0)); g.addColorStop(.8, css(accent, .12)); g.addColorStop(1, css(accent, .3)); x.fillStyle = g; x.beginPath(); x.arc(24, 24, 19, 0, TAU); x.fill();
    x.fillStyle = 'rgba(255,255,255,.85)'; x.beginPath(); x.arc(17, 16, 3.2, 0, TAU); x.fill();
  } else if (T.mote === 'star') { c = bakeStar(48, accent); }
  else { g.addColorStop(0, 'rgba(255,255,255,.95)'); g.addColorStop(.25, css(accent, .85)); g.addColorStop(.6, css(accent, .25)); g.addColorStop(1, css(accent, 0)); x.fillStyle = g; x.fillRect(0, 0, 48, 48); }
  o.mote = c;
  // فقاعات ضبابية للعمق (جواهر صغيرة تُكبَّر = ضبابية طبيعية)
  o.gems = JL.GEMS.map((_, i) => scaleTo(MASTER.gem[i], 22));
  return o;
};

JL.bake = () => { for (const s of JL.bakeSteps) s[1](); };
})();
