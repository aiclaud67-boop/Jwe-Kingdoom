/* أيقونات SVG مرسومة يدوياً بتدرجات (بديل الإيموجي حتى يبدو كل شيء موحّداً على كل الأجهزة) */
(function () {
'use strict';
const star = (() => { const p = []; for (let i = 0; i < 10; i++) { const a = -Math.PI / 2 + i * Math.PI / 5, r = i % 2 ? 12.5 : 28; p.push((32 + Math.cos(a) * r).toFixed(1) + ',' + (34 + Math.sin(a) * r).toFixed(1)); } return p.join(' '); })();
const G = 'fill="url(#gGold)" stroke="#9a5200" stroke-width="3" stroke-linejoin="round"';
const SV = 'fill="url(#gSilver)" stroke="#55648a" stroke-width="3" stroke-linejoin="round"';
const sym = (id, body) => '<symbol id="i-' + id + '" viewBox="0 0 64 64">' + body + '</symbol>';
const html = '<svg width="0" height="0" style="position:absolute" aria-hidden="true"><defs>' +
  '<linearGradient id="gGold" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fff6b0"/><stop offset=".5" stop-color="#ffc928"/><stop offset="1" stop-color="#e07e00"/></linearGradient>' +
  '<linearGradient id="gSilver" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffffff"/><stop offset=".55" stop-color="#c3cee8"/><stop offset="1" stop-color="#8393b8"/></linearGradient>' +
  '<linearGradient id="gGreen" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#b8ffd2"/><stop offset=".5" stop-color="#2fd57a"/><stop offset="1" stop-color="#0a8a47"/></linearGradient>' +
  '<linearGradient id="gRed" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffb0b8"/><stop offset=".5" stop-color="#f03a55"/><stop offset="1" stop-color="#a0102a"/></linearGradient>' +
  '<linearGradient id="gBlue" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#d8f0ff"/><stop offset=".5" stop-color="#5eb4ff"/><stop offset="1" stop-color="#1f66d8"/></linearGradient>' +
  '<linearGradient id="gWood" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#c98340"/><stop offset=".5" stop-color="#eeb26a"/><stop offset="1" stop-color="#8a4a1c"/></linearGradient></defs>' +
  sym('star', '<polygon points="' + star + '" ' + G + '/><polygon points="' + star + '" fill="none" stroke="#fff8c8" stroke-opacity=".55" stroke-width="1.5" transform="translate(32 34) scale(.72) translate(-32 -34)"/>') +
  sym('starOff', '<polygon points="' + star + '" fill="#3a2a66" stroke="#241647" stroke-width="3" stroke-linejoin="round"/>') +
  sym('play', '<path d="M20 11 L53 32 L20 53 Z" ' + G + '/>') +
  sym('pause', '<rect x="15" y="12" width="12" height="40" rx="4" ' + G + '/><rect x="37" y="12" width="12" height="40" rx="4" ' + G + '/>') +
  sym('hammer', '<g transform="rotate(-40 32 32)"><rect x="28" y="22" width="8" height="38" rx="3" fill="url(#gWood)" stroke="#5a2a0c" stroke-width="2.5"/><rect x="9" y="8" width="46" height="19" rx="5" ' + SV + '/><rect x="9" y="8" width="8" height="19" rx="3" fill="url(#gGold)" stroke="#9a5200" stroke-width="2"/><rect x="47" y="8" width="8" height="19" rx="3" fill="url(#gGold)" stroke="#9a5200" stroke-width="2"/></g>') +
  sym('shuffle', '<g fill="none" stroke="url(#gBlue)" stroke-width="7" stroke-linecap="round" stroke-linejoin="round"><path d="M8 20 H20 C32 20 32 44 44 44 H50"/><path d="M8 44 H20 C32 44 32 20 44 20 H50"/></g><path d="M46 33 L58 44 L46 55 Z M46 9 L58 20 L46 31 Z" fill="#9fd4ff" stroke="#1f66d8" stroke-width="3" stroke-linejoin="round"/>') +
  sym('plus', '<path d="M25 8 h14 v17 h17 v14 h-17 v17 h-14 v-17 h-17 v-14 h17 z" fill="url(#gGreen)" stroke="#06602f" stroke-width="3" stroke-linejoin="round"/>') +
  sym('coin', '<circle cx="32" cy="32" r="27" ' + G + '/><circle cx="32" cy="32" r="19" fill="none" stroke="#fff6b0" stroke-width="3" stroke-opacity=".9"/><path d="M32 18 L43 32 L32 47 L21 32 Z" fill="#c47a00" fill-opacity=".85" stroke="#fff6b0" stroke-width="1.5"/>') +
  sym('lock', '<path d="M21 28 V20 a11 11 0 0 1 22 0 V28" fill="none" stroke="#8393b8" stroke-width="7" stroke-linecap="round"/><rect x="12" y="28" width="40" height="29" rx="7" ' + SV + '/><circle cx="32" cy="40" r="4.5" fill="#55648a"/><rect x="30" y="42" width="4" height="8" rx="2" fill="#55648a"/>') +
  sym('crown', '<path d="M7 50 L11 18 L24 31 L32 12 L40 31 L53 18 L57 50 Z" ' + G + '/><rect x="7" y="48" width="50" height="9" rx="3" ' + G + '/><circle cx="11" cy="17" r="4" fill="url(#gRed)"/><circle cx="32" cy="11" r="4.5" fill="url(#gGreen)"/><circle cx="53" cy="17" r="4" fill="url(#gBlue)"/>') +
  sym('snow', '<g stroke="#bfefff" stroke-width="5" stroke-linecap="round" fill="none"><path d="M32 6 V58 M9.5 19 L54.5 45 M9.5 45 L54.5 19"/><path d="M25 10 L32 16 L39 10 M25 54 L32 48 L39 54 M8 28 L16 26 L14 18 M56 36 L48 38 L50 46 M8 36 L16 38 L14 46 M56 28 L48 26 L50 18" stroke-width="3.5"/></g>') +
  sym('gift', '<rect x="8" y="27" width="48" height="30" rx="5" fill="url(#gRed)" stroke="#7a0c20" stroke-width="3"/><rect x="5" y="18" width="54" height="13" rx="5" fill="url(#gRed)" stroke="#7a0c20" stroke-width="3"/><rect x="27" y="18" width="10" height="39" fill="url(#gGold)" stroke="#9a5200" stroke-width="2.5"/><path d="M32 18 C20 6 10 12 18 18 Z M32 18 C44 6 54 12 46 18 Z" ' + G + '/>') +
  sym('gear', '<circle cx="32" cy="32" r="21" fill="none" stroke="url(#gSilver)" stroke-width="9" stroke-dasharray="7.6 9.2"/><circle cx="32" cy="32" r="17" ' + SV + '/><circle cx="32" cy="32" r="7" fill="#33405f"/>') +
  sym('bag', '<path d="M21 24 V18 a11 11 0 0 1 22 0 V24" fill="none" stroke="#9a5200" stroke-width="5" stroke-linecap="round"/><path d="M10 22 H54 L50 57 H14 Z" ' + G + '/><path d="M32 30 L38 38 L32 47 L26 38 Z" fill="#fff6b0" stroke="#9a5200" stroke-width="2"/>') +
  sym('map', '<path d="M6 14 L22 8 L42 14 L58 8 V50 L42 56 L22 50 L6 56 Z" ' + G + '/><path d="M22 8 V50 M42 14 V56" stroke="#9a5200" stroke-width="2.5" fill="none"/><circle cx="32" cy="30" r="5" fill="url(#gRed)" stroke="#7a0c20" stroke-width="2"/>') +
  sym('home', '<path d="M8 32 L32 10 L56 32 H50 V54 H38 V40 H26 V54 H14 V32 Z" ' + G + '/>') +
  sym('retry', '<path d="M50 32 a18 18 0 1 1 -6 -13.5" fill="none" stroke="url(#gGold)" stroke-width="8" stroke-linecap="round"/><path d="M52 8 V24 H36 Z" fill="#ffc928" stroke="#9a5200" stroke-width="3" stroke-linejoin="round"/>') +
  sym('close', '<path d="M16 16 L48 48 M48 16 L16 48" stroke="#fff" stroke-width="9" stroke-linecap="round"/>') +
  sym('check', '<path d="M13 34 L27 48 L52 17" fill="none" stroke="url(#gGreen)" stroke-width="10" stroke-linecap="round" stroke-linejoin="round"/>') +
  sym('sound', '<path d="M8 24 H18 L32 12 V52 L18 40 H8 Z" ' + SV + '/><path d="M40 22 a14 14 0 0 1 0 20 M47 14 a24 24 0 0 1 0 36" fill="none" stroke="#c3cee8" stroke-width="5" stroke-linecap="round"/>') +
  sym('music', '<path d="M24 46 V14 L52 8 V40" fill="none" stroke="#c3cee8" stroke-width="5" stroke-linejoin="round"/><ellipse cx="18" cy="46" rx="9" ry="7" ' + SV + '/><ellipse cx="46" cy="40" rx="9" ry="7" ' + SV + '/>') +
  sym('vibe', '<rect x="20" y="8" width="24" height="48" rx="6" ' + SV + '/><path d="M8 22 V42 M2 28 V36 M56 22 V42 M62 28 V36" stroke="#c3cee8" stroke-width="4" stroke-linecap="round"/>') +
  sym('shake', '<path d="M8 20 L16 12 L24 20 L32 12 L40 20 L48 12 L56 20 M8 36 L16 28 L24 36 L32 28 L40 36 L48 28 L56 36 M8 52 L16 44 L24 52 L32 44 L40 52 L48 44 L56 52" fill="none" stroke="#c3cee8" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/>') +
  sym('info', '<circle cx="32" cy="32" r="26" ' + SV + '/><circle cx="32" cy="19" r="4.5" fill="#33405f"/><rect x="28" y="28" width="8" height="21" rx="3" fill="#33405f"/>') +
  sym('trophy', '<path d="M16 8 H48 V26 a16 16 0 0 1 -32 0 Z" ' + G + '/><path d="M16 14 H6 V22 a10 10 0 0 0 10 10 M48 14 H58 V22 a10 10 0 0 1 -10 10" fill="none" stroke="#9a5200" stroke-width="4"/><rect x="28" y="40" width="8" height="10" fill="#e07e00"/><rect x="18" y="50" width="28" height="9" rx="3" ' + G + '/>') +
  sym('back', '<path d="M40 10 L18 32 L40 54" fill="none" stroke="#fff" stroke-width="10" stroke-linecap="round" stroke-linejoin="round"/>') +
  sym('spark', '<path d="M32 4 C34 22 42 30 60 32 C42 34 34 42 32 60 C30 42 22 34 4 32 C22 30 30 22 32 4 Z" ' + G + '/>') +
  '</svg>';
document.body.insertAdjacentHTML('afterbegin', html);
window.JL.icon = (n, c) => '<svg class="ic ' + (c || '') + '"><use href="#i-' + n + '"/></svg>';
})();
