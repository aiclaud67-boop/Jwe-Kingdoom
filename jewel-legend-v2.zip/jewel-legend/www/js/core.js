/* ===========================================================
   أسطورة الجواهر — النواة: أدوات، حفظ، سمات، جودة تلقائية
   =========================================================== */
(function () {
'use strict';
const JL = window.JL = {};
JL.$ = s => document.querySelector(s);
JL.$$ = s => Array.prototype.slice.call(document.querySelectorAll(s));
JL.W = 8; JL.H = 8;
JL.rnd = n => (Math.random() * n) | 0;
JL.rand = (a, b) => a + Math.random() * (b - a);
JL.clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
JL.lerp = (a, b, t) => a + (b - a) * t;
JL.nextFrame = () => new Promise(r => requestAnimationFrame(() => r()));
JL.sleep = ms => new Promise(r => setTimeout(r, ms));
JL.TAU = Math.PI * 2;

/* ---------- السمات (الخلفيات) ---------- */
JL.THEMES = [
  { n: 'ليل ملكي',       price: 0,   c: ['#2d1270', '#170a3d', '#09031c'], blob: ['#7a3cff', '#ff4fa8', '#2f7bff'], mote: 'star',   accent: '#c9b4ff' },
  { n: 'كهف الجمر',      price: 300, c: ['#7d2412', '#3a0d0a', '#140303'], blob: ['#ff6a1a', '#ff2d4d', '#ffb000'], mote: 'ember',  accent: '#ffb070' },
  { n: 'المحيط العميق',  price: 300, c: ['#0f6d9e', '#06375c', '#02131f'], blob: ['#18c8ff', '#2a6bff', '#19ffd0'], mote: 'bubble', accent: '#8ee3ff' },
  { n: 'الغابة السحرية', price: 400, c: ['#137d4c', '#0a3f2b', '#03150e'], blob: ['#2dff9a', '#d6ff3a', '#18b8ff'], mote: 'firefly', accent: '#9dffc4' },
  { n: 'قصر الجليد',     price: 500, c: ['#315f9c', '#1a3463', '#090f2c'], blob: ['#9fe6ff', '#c9a6ff', '#ffffff'], mote: 'snow',   accent: '#d6f1ff' },
  { n: 'غروب الذهب',     price: 600, c: ['#92395c', '#4b1745', '#190720'], blob: ['#ffb84a', '#ff5a7a', '#ffe27a'], mote: 'dust',   accent: '#ffdc8a' },
];

/* ---------- الحفظ ---------- */
const KEY2 = 'jewelLegend_v2', KEY1 = 'jewelLegend_v1';
const def = () => ({
  ver: 2, coins: 300, stars: {}, inv: { hammer: 2, shuffle: 2, moves: 2 },
  sound: true, music: true, vibe: true, shake: true, sfxVol: .85, musVol: .6,
  quality: 'auto', theme: 0, themes: [0], daily: { last: '', day: 0 }, tips: {}
});
function load() {
  let o = null;
  try { o = JSON.parse(localStorage.getItem(KEY2)); } catch (e) {}
  if (!o) { try { const v = JSON.parse(localStorage.getItem(KEY1)); if (v) o = { coins: v.coins, stars: v.stars, inv: v.inv, sound: v.sound, music: v.music, vibe: v.vibe, theme: v.theme, themes: v.themes }; } catch (e) {} }
  const d = def();
  if (!o || typeof o !== 'object') return d;
  const s = Object.assign(d, o);
  s.inv = Object.assign(def().inv, o.inv || {});
  s.daily = Object.assign({ last: '', day: 0 }, o.daily || {});
  s.stars = o.stars || {}; s.tips = o.tips || {};
  if (!Array.isArray(s.themes) || !s.themes.length) s.themes = [0];
  if (!JL.THEMES[s.theme]) s.theme = 0;
  if (typeof s.coins !== 'number' || !isFinite(s.coins)) s.coins = 300;
  return s;
}
JL.S = load();
JL.save = () => { try { localStorage.setItem(KEY2, JSON.stringify(JL.S)); } catch (e) {} };
JL.resetSave = () => { JL.S = def(); JL.save(); };
JL.vib = ms => { if (JL.S.vibe && navigator.vibrate) { try { navigator.vibrate(ms); } catch (e) {} } };

/* ---------- أحداث بسيطة ---------- */
const subs = {};
JL.on = (e, f) => { (subs[e] = subs[e] || []).push(f); };
JL.emit = (e, a) => { (subs[e] || []).forEach(f => { try { f(a); } catch (er) { console.error(er); } }); };

/* ---------- الجودة: تلقائية وتتكيّف مع أداء الجهاز ---------- */
const QL = [
  { name: 'low',    dpr: 1.25, part: .35, motes: 10, blobs: 1, rays: false, bgGems: 4,  glow: false, fly: false },
  { name: 'medium', dpr: 1.75, part: .65, motes: 26, blobs: 2, rays: true,  bgGems: 7,  glow: true,  fly: true },
  { name: 'high',   dpr: 2.5,  part: 1,   motes: 48, blobs: 3, rays: true,  bgGems: 10, glow: true,  fly: true },
];
JL.Q = Object.assign({ level: 2 }, QL[2]);
function applyLevel(l) { JL.Q = Object.assign({ level: l }, QL[l]); JL.emit('quality', JL.Q); }
JL.initQuality = () => {
  const s = JL.S.quality;
  if (s === 'low') return applyLevel(0);
  if (s === 'medium') return applyLevel(1);
  if (s === 'high') return applyLevel(2);
  const cores = navigator.hardwareConcurrency || 4, mem = navigator.deviceMemory || 4;
  const px = screen.width * screen.height * Math.pow(window.devicePixelRatio || 1, 2);
  applyLevel((mem <= 2 || cores <= 4 || px > 6e6) ? 1 : 2);
};
let pAcc = 0, pN = 0, pCool = 0, pWarm = 150;
JL.perf = dt => {
  if (JL.S.quality !== 'auto' || document.hidden) return;
  if (pWarm > 0) { pWarm--; return; }
  if (dt > .25) return;
  pAcc += dt; pN++; pCool -= dt;
  if (pN >= 90) {
    const avg = pAcc / pN; pAcc = 0; pN = 0;
    JL.fps = Math.round(1 / avg);
    if (avg > .028 && pCool <= 0 && JL.Q.level > 0) { applyLevel(JL.Q.level - 1); pCool = 4; pWarm = 60; }
  }
};
JL.setQualitySetting = v => { JL.S.quality = v; JL.save(); pWarm = 60; JL.initQuality(); };

/* ---------- المراحل ---------- */
const SHAPES = [
  ['........', '........', '........', '........', '........', '........', '........', '........'],
  ['#......#', '........', '........', '........', '........', '........', '........', '#......#'],
  ['###..###', '##....##', '#......#', '........', '........', '#......#', '##....##', '###..###'],
  ['........', '........', '........', '...##...', '...##...', '........', '........', '........'],
  ['........', '#......#', '##....##', '###..###', '###..###', '##....##', '#......#', '........'],
  ['##....##', '##....##', '........', '........', '........', '........', '##....##', '##....##'],
  ['#..##..#', '........', '........', '#......#', '##....##', '###..###', '########', '########'],
];
const SH_SEQ = [0, 0, 0, 1, 0, 2, 3, 0, 4, 1, 5, 0, 2, 3, 6, 4, 1, 5, 0, 3, 2, 6, 4, 5, 3, 1, 6, 4, 5, 6];
JL.LEVELS = 30;
JL.SHAPES = SHAPES;
JL.makeLevel = n => {
  const W = JL.W, H = JL.H;
  const shape = SH_SEQ[n - 1], colors = n <= 2 ? 4 : n <= 7 ? 5 : 6, boss = n % 10 === 0;
  const kind = boss ? 3 : n <= 2 ? 0 : [1, 2, 0][n % 3];
  let moves = Math.max(18, 30 - Math.floor(n * .4));
  if (kind === 1) moves += 5; if (kind === 2) moves += 6; if (kind === 3) moves += 4;
  const goals = [];
  const scoreV = Math.round(moves * (40 + n * 1.8) / 50) * 50;
  if (kind === 0 || kind === 3) goals.push({ k: 'score', v: kind === 3 ? Math.round(scoreV * .8 / 50) * 50 : scoreV });
  if (kind === 1) {
    const v = Math.round(10 + n * .45), t1 = (n * 3) % colors;
    if (n >= 12) goals.push({ k: 'col', t: t1, v: Math.round(v * .7) }, { k: 'col', t: (t1 + 2) % colors, v: Math.round(v * .7) });
    else goals.push({ k: 'col', t: t1, v });
  }
  const ice = [];
  if (kind >= 2) {
    goals.push({ k: 'ice' });
    const pat = n % 5, sh = SHAPES[shape];
    for (let r = 0; r < H; r++) for (let c = 0; c < W; c++) {
      if (sh[r][c] === '#') continue;
      const on = pat === 0 ? r >= H - 3 : pat === 1 ? (r + c) % 2 === 0 : pat === 2 ? (r >= 2 && r <= 5 && c >= 2 && c <= 5) : pat === 3 ? (r === 0 || c === 0 || r === H - 1 || c === W - 1) : true;
      if (on) ice.push([r, c, (n >= 16 && (r + c) % 2 === 0) ? 2 : 1]);
    }
  }
  return { n, colors, shape, moves, goals, ice, boss, kind };
};
JL.unlocked = n => n === 1 || (JL.S.stars[n - 1] || 0) > 0;
JL.nextLevel = () => { for (let i = 1; i <= JL.LEVELS; i++) if (!(JL.S.stars[i] > 0)) return i; return JL.LEVELS; };
JL.totalStars = () => { let t = 0; for (let i = 1; i <= JL.LEVELS; i++) t += JL.S.stars[i] || 0; return t; };
})();
